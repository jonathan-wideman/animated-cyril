(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var BuildingController,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BuildingController = require("./BuildingController").BuildingController;

exports.Building = (function(_super) {
  __extends(Building, _super);

  function Building(game) {
    var x, y;
    this.game = game;
    this.update = __bind(this.update, this);
    x = this.game.world.centerX;
    y = this.game.world.centerY;
    Building.__super__.constructor.call(this, this.game, x, y, 'player');
    this.anchor.setTo(0.5, 0.5);
    this.controller = new BuildingController(this.game, this);
    return this;
  }

  Building.prototype.update = function() {
    return this.controller.update();
  };

  return Building;

})(Phaser.Sprite);



},{"./BuildingController":2}],2:[function(require,module,exports){
exports.BuildingController = (function() {
  function BuildingController(game, building) {
    this.game = game;
    this.building = building;
    this.building.inputEnabled = true;
    this.building.input.enableDrag();
    this.building.input.enableSnap(32, 32, true, true);
  }

  BuildingController.prototype.update = function() {};

  return BuildingController;

})();



},{}],3:[function(require,module,exports){
var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

exports.Enemy = (function(_super) {
  __extends(Enemy, _super);

  Enemy.prototype.MAX_SPEED = 100;

  Enemy.prototype.MIN_DISTANCE = 64;

  function Enemy(game, player) {
    var x, y;
    this.game = game;
    this.player = player;
    this.update = __bind(this.update, this);
    x = this.game.world.centerX;
    y = this.game.world.centerY;
    Enemy.__super__.constructor.call(this, this.game, x, y, 'enemy');
    this.anchor.setTo(0.5, 0.5);
    this.animations.add('up', [0, 1, 2, 3], 10, true);
    this.animations.add('down', [4, 5, 6, 7], 10, true);
    this.animations.add('left', [8, 9, 10, 11], 10, true);
    this.animations.add('right', [12, 13, 14, 15], 10, true);
    this.game.physics.enable(this, Phaser.Physics.ARCADE);
    game.add.existing(this);
    this.animations.play('down');
    return this;
  }

  Enemy.prototype.update = function() {
    this.follow(this.player);
    return this.updateFacing();
  };

  Enemy.prototype.updateFacing = function() {
    var dir, h, v;
    h = this.body.velocity.x < 0 ? 'left' : 'right';
    v = this.body.velocity.y < 0 ? 'up' : 'down';
    dir = Math.abs(this.body.velocity.x) > Math.abs(this.body.velocity.y) ? h : v;
    return this.animations.play(dir);
  };

  Enemy.prototype.newDirection = function() {
    var direction;
    direction = this.game.rand.pick(['up', 'down', 'left', 'right']);
    console.log(direction);
    return direction;
  };

  Enemy.prototype.follow = function(target) {
    var angleToTarget, distance;
    distance = this.game.math.distance(this.x, this.y, target.x, target.y);
    if (distance > this.MIN_DISTANCE) {
      angleToTarget = this.game.math.angleBetween(this.x, this.y, target.x, target.y);
      this.body.velocity.x = Math.cos(angleToTarget) * this.MAX_SPEED;
      return this.body.velocity.y = Math.sin(angleToTarget) * this.MAX_SPEED;
    } else {
      return this.body.velocity.setTo(0, 0);
    }
  };

  return Enemy;

})(Phaser.Sprite);



},{}],4:[function(require,module,exports){
exports.Juice = (function() {
  function Juice(game) {
    this.game = game;
    this.defaultSoundVolume = 1;
    this.sndTile = game.add.sound('sndTile', this.defaultSoundVolume);
    this.sndTile.allowMultiple = true;
    this.sndMissile = game.add.sound('sndMissile', this.defaultSoundVolume);
    this.sndTile.allowMultiple = true;
    this.emitter = game.add.emitter(0, 0, 1000);
    this.emitter.makeParticles('particle');
    this.emitter.gravity = 300;
    return this;
  }

  Juice.prototype.shake = function() {
    return this.game.add.tween(this.game.camera).from({
      y: this.game.camera.y - 5
    }, 50, Phaser.Easing.Sinusoidal.InOut, false, 0, 4, true).start();
  };

  Juice.prototype.splode = function(x, y) {
    this.emitter.x = x;
    this.emitter.y = y;
    return this.emitter.start(true, 250, null, 5);
  };

  Juice.prototype.pew = function() {
    return this.sndMissile.play();
  };

  Juice.prototype.plop = function(x, y) {
    this.sndTile.play();
    return this.splode(x, y);
  };

  return Juice;

})();



},{}],5:[function(require,module,exports){
var Building, Enemy, Juice, Player, ToolMissile, gamestate;

Juice = require("./Juice").Juice;

Player = require("./Player").Player;

Building = require("./Building").Building;

Enemy = require("./Enemy").Enemy;

ToolMissile = require("./ToolMissile").ToolMissile;

window.onload = function() {
  return window.game = new Phaser.Game(640, 640, Phaser.CANVAS, 'game-container', gamestate);
};

gamestate = {
  preload: function() {
    game.load.image('tileSelect', 'assets/img/star1.png');
    game.load.image('star2', 'assets/img/star2.png');
    game.load.image('missile', 'assets/img/star3.png');
    game.load.image('particle', 'assets/img/flash.png');
    game.load.spritesheet('player', 'assets/img/player.png', 32, 32);
    game.load.spritesheet('enemy', 'assets/img/enemy.png', 64, 64);
    game.load.image('tiles', 'assets/img/tiles.png');
    game.load.audio('sndMissile', 'assets/snd/steam.ogg');
    return game.load.audio('sndTile', 'assets/snd/rollover6.wav');
  },
  create: function() {
    var MAP_HEIGHT, MAP_WIDTH, MAX_ASTEROIDS, layer1;
    MAX_ASTEROIDS = 100;
    this.asteroidGroup = this.game.add.group();
    this.asteroidGroup.enableBody = true;
    this.asteroidGroup.physicsBodyType = Phaser.Physics.ARCADE;
    this.asteroidGroup.createMultiple(MAX_ASTEROIDS, 'particle', 0);
    this.asteroidTimer = 0;
    this.map = game.add.tilemap();
    this.map.addTilesetImage('tiles');
    MAP_WIDTH = 40;
    MAP_HEIGHT = 30;
    layer1 = this.map.create('level1', MAP_WIDTH, MAP_HEIGHT, 32, 32);
    layer1.resizeWorld();
    this.currentLayer = layer1;
    this.currentTile = 7;
    this.map.fill(this.currentTile, 0, 0, MAP_WIDTH, MAP_HEIGHT, this.currentLayer);
    this.currentTile = 0;
    this.map.fill(this.currentTile, 10, 10, 18, 10, this.currentLayer);
    this.game.currentLevel = {
      tilemap: this.map,
      currentLayer: this.currentLayer
    };
    this.map.setCollision([7], true, 'level1');
    this.player = new Player(game);
    this.enemy = new Enemy(game, this.player);
    this.game.camera.follow(this.player, Phaser.Camera.FOLLOW_TOPDOWN_TIGHT);
    this.game.juice = new Juice(this.game);
    this.game.time.advancedTiming = true;
    this.statusText = this.game.add.text(20, 20, '', {
      font: '16px Arial',
      fill: '#ffffff'
    });
    return this.statusText.fixedToCamera = true;
  },
  update: function() {
    this.game.physics.arcade.collide(this.player, this.currentLayer);
    this.statusText.setText(this.getStatusText());
    this.asteroidTimer -= this.game.time.elapsed;
    if (this.asteroidTimer <= 0) {
      this.asteroidTimer = this.game.rnd.integerInRange(5, 50);
      return this.createNewAsteroid();
    }
  },
  createNewAsteroid: function() {
    var asteroid, depth, direction, dx, dy, fast, slow, sx, sy;
    asteroid = this.asteroidGroup.getFirstDead();
    if (asteroid) {
      dx = 0;
      dy = 0;
      slow = 10;
      fast = 50;
      while (dx < slow && dx > -slow && dy < slow && dy > -slow) {
        dx = this.game.rnd.between(-fast, fast);
        dy = this.game.rnd.between(-fast, fast);
      }
      sx = dx > 0 ? 0 : this.game.world.width;
      sy = dy > 0 ? 0 : this.game.world.height;
      direction = this.game.rnd.pick(['h', 'v']);
      sx = direction === 'h' ? this.game.rnd.between(0, this.game.world.width) : sx;
      sy = direction === 'v' ? this.game.rnd.between(0, this.game.world.height) : sy;
      asteroid.reset(sx, sy);
      asteroid.revive();
      depth = this.game.rnd.realInRange(0.1, 0.8);
      asteroid.alpha = depth;
      asteroid.body.velocity.setTo(0, 0);
      asteroid.body.acceleration.setTo(0, 0);
      asteroid.body.velocity.x = dx;
      asteroid.body.velocity.y = dy;
      asteroid.rotation = Phaser.Math.degToRad(this.game.rnd.angle());
      asteroid.frame = 0;
      asteroid.anchor.setTo(0.5, 0.5);
      asteroid.checkWorldBounds = true;
      return asteroid.outOfBoundsKill = true;
    }
  },
  getStatusText: function() {
    var status;
    status = '';
    status += this.game.time.fps + ' FPS' + '\n';
    status += 'TOOL: ' + this.player.tool.name + '\n';
    status += this.player.tool.getStatusText();
    return status;
  }
};



},{"./Building":1,"./Enemy":3,"./Juice":4,"./Player":6,"./ToolMissile":9}],6:[function(require,module,exports){
var PlayerController, ToolBuild, ToolMissile, ToolTeleport,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

PlayerController = require("./PlayerController").PlayerController;

ToolMissile = require("./ToolMissile").ToolMissile;

ToolBuild = require("./ToolBuild").ToolBuild;

ToolTeleport = require("./ToolTeleport").ToolTeleport;

exports.Player = (function(_super) {
  __extends(Player, _super);

  Player.prototype.speed = 250;

  function Player(game) {
    var x, y;
    this.game = game;
    this.update = __bind(this.update, this);
    x = this.game.world.centerX;
    y = this.game.world.centerY;
    Player.__super__.constructor.call(this, this.game, x, y, 'player');
    this.anchor.setTo(0.5, 0.5);
    this.animations.add('idle', [0]);
    this.animations.add('cast', [1]);
    this.game.physics.enable(this, Phaser.Physics.ARCADE);
    this.controller = new PlayerController(this.game, this);
    game.add.existing(this);
    this.tools = [new ToolMissile(this.game, this), new ToolTeleport(this.game, this), new ToolBuild(this.game, this)];
    this.nextTool();
    return this;
  }

  Player.prototype.update = function() {
    this.controller.update();
    if (this.tool != null) {
      return this.tool.update();
    }
  };

  Player.prototype.nextTool = function() {
    if (this.tool) {
      this.tool.unselect();
    }
    this.tool = this.tools.pop();
    if (this.tool) {
      this.tools.unshift(this.tool);
      return this.tool.select();
    }
  };

  return Player;

})(Phaser.Sprite);



},{"./PlayerController":7,"./ToolBuild":8,"./ToolMissile":9,"./ToolTeleport":10}],7:[function(require,module,exports){
var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

exports.PlayerController = (function() {
  PlayerController.prototype.keyboard_modes = {
    QWERTY: {
      up: Phaser.Keyboard.W,
      down: Phaser.Keyboard.S,
      left: Phaser.Keyboard.A,
      right: Phaser.Keyboard.D
    },
    DVORAK: {
      up: 188,
      down: Phaser.Keyboard.O,
      left: Phaser.Keyboard.A,
      right: Phaser.Keyboard.E
    }
  };

  function PlayerController(game, player) {
    this.game = game;
    this.player = player;
    this.setKeymap = __bind(this.setKeymap, this);
    this.cursors = game.input.keyboard.createCursorKeys();
    this.setKeymap("QWERTY");
  }

  PlayerController.prototype.setKeymap = function(mode) {
    if (this.keyboard_modes[mode] != null) {
      return this.keyboard_mode = this.keyboard_modes[mode];
    }
  };

  PlayerController.prototype.update = function() {
    this.player.body.velocity.x = 0;
    this.player.body.velocity.y = 0;
    if (this.cursors.left.isDown || this.game.input.keyboard.isDown(this.keyboard_mode.left)) {
      this.player.body.velocity.x = -1 * this.player.speed;
    } else if (this.cursors.right.isDown || this.game.input.keyboard.isDown(this.keyboard_mode.right)) {
      this.player.body.velocity.x = this.player.speed;
    }
    if (this.cursors.up.isDown || this.game.input.keyboard.isDown(this.keyboard_mode.up)) {
      this.player.body.velocity.y = -1 * this.player.speed;
    } else if (this.cursors.down.isDown || this.game.input.keyboard.isDown(this.keyboard_mode.down)) {
      this.player.body.velocity.y = this.player.speed;
    }
    if (this.game.input.keyboard.downDuration(Phaser.Keyboard.SPACEBAR, 10)) {
      return this.player.nextTool();
    }
  };

  return PlayerController;

})();



},{}],8:[function(require,module,exports){
var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

exports.ToolBuild = (function() {
  ToolBuild.prototype.name = "Build";

  ToolBuild.prototype.currentTileId = 0;

  ToolBuild.prototype.tilemap = null;

  function ToolBuild(game, player) {
    this.game = game;
    this.player = player;
    this.update = __bind(this.update, this);
    this.gun = this.game.add.sprite(50, this.game.height / 2, 'star2');
    this.gun.anchor.setTo(0.5, 0.5);
    this.gun.visible = false;
    this.selection = this.game.add.sprite(50, this.game.height / 2, 'tileSelect');
    this.selection.anchor.setTo(0.5, 0.5);
    this.currentTile = 0;
    this.map = this.game.currentLevel.tilemap;
    this.currentLayer = this.game.currentLevel.currentLayer;
    return this;
  }

  ToolBuild.prototype.showPallete = function() {};

  ToolBuild.prototype.hidePallete = function() {};

  ToolBuild.prototype.pickPalleteTile = function() {};

  ToolBuild.prototype.pickTile = function(x, y) {
    if (this.tilemap == null) {
      console.log("ToolBuild.pickTile: @tilemap does not exist");
      return;
    }
    return this.currentTileId = 0;
  };

  ToolBuild.prototype.paintTile = function(x, y) {
    if (this.tilemap == null) {
      console.log("ToolBuild.paintTile: @tilemap does not exist");
    }
  };

  ToolBuild.prototype.coordsScreenToTilemap = function(x, y) {};

  ToolBuild.prototype.update = function() {
    var markerX, markerY;
    this.gun.x = this.player.x;
    this.gun.y = this.player.y;
    this.selection.x = Math.floor(this.game.input.activePointer.worldX / 32) * 32 + 16;
    this.selection.y = Math.floor(this.game.input.activePointer.worldY / 32) * 32 + 16;
    markerX = this.currentLayer.getTileX(game.input.activePointer.worldX) * 32;
    markerY = this.currentLayer.getTileY(game.input.activePointer.worldY) * 32;
    if (this.game.input.mousePointer.isDown) {
      this.player.animations.play('cast');
      if (game.input.keyboard.isDown(Phaser.Keyboard.SHIFT)) {
        this.currentTile = this.map.getTile(this.currentLayer.getTileX(markerX), this.currentLayer.getTileY(markerY)).index;
      } else {
        if (this.map.getTile(this.currentLayer.getTileX(markerX), this.currentLayer.getTileY(markerY)).index !== this.currentTile) {
          this.map.putTile(this.currentTile, this.currentLayer.getTileX(markerX), this.currentLayer.getTileY(markerY));
          this.game.juice.plop(game.input.activePointer.worldX, game.input.activePointer.worldY);
        }
      }
    } else {
      this.player.animations.play('idle');
    }
    if (this.game.input.keyboard.downDuration(Phaser.Keyboard.Q, 10)) {
      this.currentTile = Phaser.Math.clamp(this.currentTile - 1, 0, 7);
    }
    if (this.game.input.keyboard.downDuration(Phaser.Keyboard.E, 10)) {
      return this.currentTile = Phaser.Math.clamp(this.currentTile + 1, 0, 7);
    }
  };

  ToolBuild.prototype.getStatusText = function() {
    var status;
    status = '';
    status += 'tileID: ' + this.currentTile + '\n';
    return status;
  };

  ToolBuild.prototype.select = function() {
    return this.selection.revive();
  };

  ToolBuild.prototype.unselect = function() {
    return this.selection.kill();
  };

  return ToolBuild;

})();



},{}],9:[function(require,module,exports){
var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

exports.ToolMissile = (function() {
  ToolMissile.prototype.name = "Magic Missile";

  ToolMissile.prototype.SHOT_DELAY = 250;

  ToolMissile.prototype.BULLET_SPEED = 450;

  ToolMissile.prototype.NUMBER_OF_BULLETS = 20;

  ToolMissile.prototype.ROTATION_OFFSET = 0;

  ToolMissile.prototype.BULLET_ENERGY_COST = 50;

  function ToolMissile(game, player) {
    this.game = game;
    this.player = player;
    this.update = __bind(this.update, this);
    this.ROTATION_OFFSET = Phaser.Math.degToRad(90);
    this.gun = this.game.add.sprite(50, this.game.height / 2, 'missile');
    this.gun.visible = false;
    this.gun.anchor.setTo(0.5, 0.5);
    this.createBullets();
    return this;
  }

  ToolMissile.prototype.update = function() {
    this.gun.x = this.player.x;
    this.gun.y = this.player.y;
    this.gun.rotation = this.game.physics.arcade.angleToPointer(this.gun);
    if (this.fireInputIsActive()) {
      this.player.animations.play('cast');
      return this.shootBullet();
    } else {
      return this.player.animations.play('idle');
    }
  };

  ToolMissile.prototype.fireInputIsActive = function() {
    var fireButton, isActive;
    isActive = false;
    fireButton = this.game.input.mouse.button === Phaser.Mouse.LEFT_BUTTON;
    return fireButton;
  };

  ToolMissile.prototype.createBullets = function() {
    var bullet, i, _i, _ref, _results;
    this.bulletPool = this.game.add.group();
    _results = [];
    for (i = _i = 0, _ref = this.NUMBER_OF_BULLETS; 0 <= _ref ? _i <= _ref : _i >= _ref; i = 0 <= _ref ? ++_i : --_i) {
      bullet = this.game.add.sprite(0, 0, 'missile');
      this.bulletPool.add(bullet);
      bullet.anchor.setTo(0.5, 0.5);
      this.game.physics.enable(bullet, Phaser.Physics.ARCADE);
      bullet.power = 1;
      _results.push(bullet.kill());
    }
    return _results;
  };

  ToolMissile.prototype.shootBullet = function() {
    var bullet;
    if (this.lastBulletShotAt === void 0) {
      this.lastBulletShotAt = 0;
    }
    if (this.game.time.now - this.lastBulletShotAt < this.SHOT_DELAY) {
      return;
    }
    this.lastBulletShotAt = this.game.time.now;
    bullet = this.bulletPool.getFirstDead();
    if (bullet === null || bullet === void 0) {
      return;
    }
    bullet.revive();
    bullet.checkWorldBounds = true;
    bullet.outOfBoundsKill = true;
    bullet.reset(this.gun.x, this.gun.y);
    bullet.rotation = this.gun.rotation - this.ROTATION_OFFSET;
    bullet.body.velocity.x = Math.cos(bullet.rotation + this.ROTATION_OFFSET) * this.BULLET_SPEED;
    bullet.body.velocity.y = Math.sin(bullet.rotation + this.ROTATION_OFFSET) * this.BULLET_SPEED;
    return this.game.juice.pew();
  };

  ToolMissile.prototype.getStatusText = function() {
    return '';
  };

  ToolMissile.prototype.select = function() {};

  ToolMissile.prototype.unselect = function() {};

  return ToolMissile;

})();



},{}],10:[function(require,module,exports){
var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

exports.ToolTeleport = (function() {
  ToolTeleport.prototype.name = "Teleport";

  ToolTeleport.prototype.cooldown = 100;

  function ToolTeleport(game, player) {
    this.game = game;
    this.player = player;
    this.update = __bind(this.update, this);
    this.teleporting = false;
    return this;
  }

  ToolTeleport.prototype.update = function() {
    if (!this.teleporting) {
      if (this.game.input.mousePointer.justReleased(this.cooldown)) {
        this.player.animations.play('cast');
        this.player.x = game.input.activePointer.worldX;
        this.player.y = game.input.activePointer.worldY;
        this.game.juice.plop(this.player.x, this.player.y);
        return this.teleporting = true;
      }
    } else {
      if (!this.game.input.mousePointer.justReleased(this.cooldown)) {
        this.player.animations.play('idle');
        return this.teleporting = false;
      }
    }
  };

  ToolTeleport.prototype.getStatusText = function() {
    return 'teleporting: ' + this.teleporting;
  };

  ToolTeleport.prototype.select = function() {};

  ToolTeleport.prototype.unselect = function() {};

  return ToolTeleport;

})();



},{}]},{},[5])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2p3aWRlbWFuL2Rldi9nYW1lcy93aXphcmQvbm9kZV9tb2R1bGVzL2d1bHAtYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiL2hvbWUvandpZGVtYW4vZGV2L2dhbWVzL3dpemFyZC9zcmMvc2NyaXB0cy9CdWlsZGluZy5jb2ZmZWUiLCIvaG9tZS9qd2lkZW1hbi9kZXYvZ2FtZXMvd2l6YXJkL3NyYy9zY3JpcHRzL0J1aWxkaW5nQ29udHJvbGxlci5jb2ZmZWUiLCIvaG9tZS9qd2lkZW1hbi9kZXYvZ2FtZXMvd2l6YXJkL3NyYy9zY3JpcHRzL0VuZW15LmNvZmZlZSIsIi9ob21lL2p3aWRlbWFuL2Rldi9nYW1lcy93aXphcmQvc3JjL3NjcmlwdHMvSnVpY2UuY29mZmVlIiwiL2hvbWUvandpZGVtYW4vZGV2L2dhbWVzL3dpemFyZC9zcmMvc2NyaXB0cy9NYWluLmNvZmZlZSIsIi9ob21lL2p3aWRlbWFuL2Rldi9nYW1lcy93aXphcmQvc3JjL3NjcmlwdHMvUGxheWVyLmNvZmZlZSIsIi9ob21lL2p3aWRlbWFuL2Rldi9nYW1lcy93aXphcmQvc3JjL3NjcmlwdHMvUGxheWVyQ29udHJvbGxlci5jb2ZmZWUiLCIvaG9tZS9qd2lkZW1hbi9kZXYvZ2FtZXMvd2l6YXJkL3NyYy9zY3JpcHRzL1Rvb2xCdWlsZC5jb2ZmZWUiLCIvaG9tZS9qd2lkZW1hbi9kZXYvZ2FtZXMvd2l6YXJkL3NyYy9zY3JpcHRzL1Rvb2xNaXNzaWxlLmNvZmZlZSIsIi9ob21lL2p3aWRlbWFuL2Rldi9nYW1lcy93aXphcmQvc3JjL3NjcmlwdHMvVG9vbFRlbGVwb3J0LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBLElBQUEsa0JBQUE7RUFBQTs7aVNBQUE7O0FBQUEsa0JBQUEsR0FBcUIsT0FBQSxDQUFRLHNCQUFSLENBQStCLENBQUMsa0JBQXJELENBQUE7O0FBQUEsT0FFYSxDQUFDO0FBRVYsNkJBQUEsQ0FBQTs7QUFBYSxFQUFBLGtCQUFFLElBQUYsR0FBQTtBQUdULFFBQUEsSUFBQTtBQUFBLElBSFUsSUFBQyxDQUFBLE9BQUEsSUFHWCxDQUFBO0FBQUEsMkNBQUEsQ0FBQTtBQUFBLElBQUEsQ0FBQSxHQUFJLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQWhCLENBQUE7QUFBQSxJQUNBLENBQUEsR0FBSSxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQURoQixDQUFBO0FBQUEsSUFJQSwwQ0FBTSxJQUFDLENBQUEsSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsUUFBbkIsQ0FKQSxDQUFBO0FBQUEsSUFPQSxJQUFDLENBQUEsTUFBTSxDQUFDLEtBQVIsQ0FBYyxHQUFkLEVBQW1CLEdBQW5CLENBUEEsQ0FBQTtBQUFBLElBYUEsSUFBQyxDQUFBLFVBQUQsR0FBa0IsSUFBQSxrQkFBQSxDQUFtQixJQUFDLENBQUEsSUFBcEIsRUFBMEIsSUFBMUIsQ0FibEIsQ0FBQTtBQWVBLFdBQU8sSUFBUCxDQWxCUztFQUFBLENBQWI7O0FBQUEscUJBcUJBLE1BQUEsR0FBUSxTQUFBLEdBQUE7V0FHSixJQUFDLENBQUEsVUFBVSxDQUFDLE1BQVosQ0FBQSxFQUhJO0VBQUEsQ0FyQlIsQ0FBQTs7a0JBQUE7O0dBRjJCLE1BQU0sQ0FBQyxPQUZ0QyxDQUFBOzs7OztBQ0FBLE9BQWEsQ0FBQztBQUVHLEVBQUEsNEJBQUUsSUFBRixFQUFTLFFBQVQsR0FBQTtBQUVULElBRlUsSUFBQyxDQUFBLE9BQUEsSUFFWCxDQUFBO0FBQUEsSUFGaUIsSUFBQyxDQUFBLFdBQUEsUUFFbEIsQ0FBQTtBQUFBLElBQUEsSUFBQyxDQUFBLFFBQVEsQ0FBQyxZQUFWLEdBQXlCLElBQXpCLENBQUE7QUFBQSxJQUNBLElBQUMsQ0FBQSxRQUFRLENBQUMsS0FBSyxDQUFDLFVBQWhCLENBQUEsQ0FEQSxDQUFBO0FBQUEsSUFFQSxJQUFDLENBQUEsUUFBUSxDQUFDLEtBQUssQ0FBQyxVQUFoQixDQUEyQixFQUEzQixFQUErQixFQUEvQixFQUFtQyxJQUFuQyxFQUF5QyxJQUF6QyxDQUZBLENBRlM7RUFBQSxDQUFiOztBQUFBLCtCQU9BLE1BQUEsR0FBUSxTQUFBLEdBQUEsQ0FQUixDQUFBOzs0QkFBQTs7SUFGSixDQUFBOzs7OztBQ0FBLElBQUE7O2lTQUFBOztBQUFBLE9BQWEsQ0FBQztBQUVWLDBCQUFBLENBQUE7O0FBQUEsa0JBQUEsU0FBQSxHQUFXLEdBQVgsQ0FBQTs7QUFBQSxrQkFDQSxZQUFBLEdBQWMsRUFEZCxDQUFBOztBQUdhLEVBQUEsZUFBRSxJQUFGLEVBQVMsTUFBVCxHQUFBO0FBR1QsUUFBQSxJQUFBO0FBQUEsSUFIVSxJQUFDLENBQUEsT0FBQSxJQUdYLENBQUE7QUFBQSxJQUhpQixJQUFDLENBQUEsU0FBQSxNQUdsQixDQUFBO0FBQUEsMkNBQUEsQ0FBQTtBQUFBLElBQUEsQ0FBQSxHQUFJLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQWhCLENBQUE7QUFBQSxJQUNBLENBQUEsR0FBSSxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQURoQixDQUFBO0FBQUEsSUFJQSx1Q0FBTSxJQUFDLENBQUEsSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsT0FBbkIsQ0FKQSxDQUFBO0FBQUEsSUFPQSxJQUFDLENBQUEsTUFBTSxDQUFDLEtBQVIsQ0FBYyxHQUFkLEVBQW1CLEdBQW5CLENBUEEsQ0FBQTtBQUFBLElBVUEsSUFBQyxDQUFBLFVBQVUsQ0FBQyxHQUFaLENBQWdCLElBQWhCLEVBQXNCLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixDQUF0QixFQUFvQyxFQUFwQyxFQUF3QyxJQUF4QyxDQVZBLENBQUE7QUFBQSxJQVdBLElBQUMsQ0FBQSxVQUFVLENBQUMsR0FBWixDQUFnQixNQUFoQixFQUF3QixDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLENBQVYsQ0FBeEIsRUFBc0MsRUFBdEMsRUFBMEMsSUFBMUMsQ0FYQSxDQUFBO0FBQUEsSUFZQSxJQUFDLENBQUEsVUFBVSxDQUFDLEdBQVosQ0FBZ0IsTUFBaEIsRUFBd0IsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLEVBQVAsRUFBVyxFQUFYLENBQXhCLEVBQXdDLEVBQXhDLEVBQTRDLElBQTVDLENBWkEsQ0FBQTtBQUFBLElBYUEsSUFBQyxDQUFBLFVBQVUsQ0FBQyxHQUFaLENBQWdCLE9BQWhCLEVBQXlCLENBQUMsRUFBRCxFQUFLLEVBQUwsRUFBUyxFQUFULEVBQWEsRUFBYixDQUF6QixFQUEyQyxFQUEzQyxFQUErQyxJQUEvQyxDQWJBLENBQUE7QUFBQSxJQWdCQSxJQUFDLENBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFkLENBQXFCLElBQXJCLEVBQXdCLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBdkMsQ0FoQkEsQ0FBQTtBQUFBLElBbUJBLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBVCxDQUFrQixJQUFsQixDQW5CQSxDQUFBO0FBQUEsSUFxQkEsSUFBQyxDQUFBLFVBQVUsQ0FBQyxJQUFaLENBQWlCLE1BQWpCLENBckJBLENBQUE7QUF1QkEsV0FBTyxJQUFQLENBMUJTO0VBQUEsQ0FIYjs7QUFBQSxrQkFnQ0EsTUFBQSxHQUFRLFNBQUEsR0FBQTtBQUNKLElBQUEsSUFBQyxDQUFBLE1BQUQsQ0FBUSxJQUFDLENBQUEsTUFBVCxDQUFBLENBQUE7V0FDQSxJQUFDLENBQUEsWUFBRCxDQUFBLEVBRkk7RUFBQSxDQWhDUixDQUFBOztBQUFBLGtCQW9DQSxZQUFBLEdBQWMsU0FBQSxHQUFBO0FBQ1YsUUFBQSxTQUFBO0FBQUEsSUFBQSxDQUFBLEdBQU8sSUFBQyxDQUFBLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBZixHQUFtQixDQUF0QixHQUE2QixNQUE3QixHQUF5QyxPQUE3QyxDQUFBO0FBQUEsSUFDQSxDQUFBLEdBQU8sSUFBQyxDQUFBLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBZixHQUFtQixDQUF0QixHQUE2QixJQUE3QixHQUF1QyxNQUQzQyxDQUFBO0FBQUEsSUFFQSxHQUFBLEdBQVMsSUFBSSxDQUFDLEdBQUwsQ0FBUyxJQUFDLENBQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUF4QixDQUFBLEdBQTZCLElBQUksQ0FBQyxHQUFMLENBQVMsSUFBQyxDQUFBLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBeEIsQ0FBaEMsR0FBZ0UsQ0FBaEUsR0FBdUUsQ0FGN0UsQ0FBQTtXQUdBLElBQUMsQ0FBQSxVQUFVLENBQUMsSUFBWixDQUFpQixHQUFqQixFQUpVO0VBQUEsQ0FwQ2QsQ0FBQTs7QUFBQSxrQkEwQ0EsWUFBQSxHQUFjLFNBQUEsR0FBQTtBQUNWLFFBQUEsU0FBQTtBQUFBLElBQUEsU0FBQSxHQUFZLElBQUMsQ0FBQSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQVgsQ0FBZ0IsQ0FBQyxJQUFELEVBQU8sTUFBUCxFQUFlLE1BQWYsRUFBdUIsT0FBdkIsQ0FBaEIsQ0FBWixDQUFBO0FBQUEsSUFDQSxPQUFPLENBQUMsR0FBUixDQUFZLFNBQVosQ0FEQSxDQUFBO0FBRUEsV0FBTyxTQUFQLENBSFU7RUFBQSxDQTFDZCxDQUFBOztBQUFBLGtCQStDQSxNQUFBLEdBQVEsU0FBQyxNQUFELEdBQUE7QUFFSixRQUFBLHVCQUFBO0FBQUEsSUFBQSxRQUFBLEdBQVcsSUFBQyxDQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBWCxDQUFvQixJQUFDLENBQUEsQ0FBckIsRUFBd0IsSUFBQyxDQUFBLENBQXpCLEVBQTRCLE1BQU0sQ0FBQyxDQUFuQyxFQUFzQyxNQUFNLENBQUMsQ0FBN0MsQ0FBWCxDQUFBO0FBR0EsSUFBQSxJQUFJLFFBQUEsR0FBVyxJQUFDLENBQUEsWUFBaEI7QUFFSSxNQUFBLGFBQUEsR0FBZ0IsSUFBQyxDQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWCxDQUF3QixJQUFDLENBQUEsQ0FBekIsRUFBNEIsSUFBQyxDQUFBLENBQTdCLEVBQWdDLE1BQU0sQ0FBQyxDQUF2QyxFQUEwQyxNQUFNLENBQUMsQ0FBakQsQ0FBaEIsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBZixHQUFtQixJQUFJLENBQUMsR0FBTCxDQUFTLGFBQVQsQ0FBQSxHQUEwQixJQUFDLENBQUEsU0FIOUMsQ0FBQTthQUlBLElBQUMsQ0FBQSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQWYsR0FBbUIsSUFBSSxDQUFDLEdBQUwsQ0FBUyxhQUFULENBQUEsR0FBMEIsSUFBQyxDQUFBLFVBTmxEO0tBQUEsTUFBQTthQVFJLElBQUMsQ0FBQSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQWYsQ0FBcUIsQ0FBckIsRUFBd0IsQ0FBeEIsRUFSSjtLQUxJO0VBQUEsQ0EvQ1IsQ0FBQTs7ZUFBQTs7R0FGd0IsTUFBTSxDQUFDLE9BQW5DLENBQUE7Ozs7O0FDQUEsT0FBYSxDQUFDO0FBRUcsRUFBQSxlQUFFLElBQUYsR0FBQTtBQUVULElBRlUsSUFBQyxDQUFBLE9BQUEsSUFFWCxDQUFBO0FBQUEsSUFBQSxJQUFDLENBQUEsa0JBQUQsR0FBc0IsQ0FBdEIsQ0FBQTtBQUFBLElBR0EsSUFBQyxDQUFBLE9BQUQsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQVQsQ0FBZSxTQUFmLEVBQTBCLElBQUMsQ0FBQSxrQkFBM0IsQ0FIWCxDQUFBO0FBQUEsSUFJQSxJQUFDLENBQUEsT0FBTyxDQUFDLGFBQVQsR0FBeUIsSUFKekIsQ0FBQTtBQUFBLElBTUEsSUFBQyxDQUFBLFVBQUQsR0FBYyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQVQsQ0FBZSxZQUFmLEVBQTZCLElBQUMsQ0FBQSxrQkFBOUIsQ0FOZCxDQUFBO0FBQUEsSUFPQSxJQUFDLENBQUEsT0FBTyxDQUFDLGFBQVQsR0FBeUIsSUFQekIsQ0FBQTtBQUFBLElBV0EsSUFBQyxDQUFBLE9BQUQsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQVQsQ0FBaUIsQ0FBakIsRUFBb0IsQ0FBcEIsRUFBdUIsSUFBdkIsQ0FYWCxDQUFBO0FBQUEsSUFhQSxJQUFDLENBQUEsT0FBTyxDQUFDLGFBQVQsQ0FBdUIsVUFBdkIsQ0FiQSxDQUFBO0FBQUEsSUFjQSxJQUFDLENBQUEsT0FBTyxDQUFDLE9BQVQsR0FBbUIsR0FkbkIsQ0FBQTtBQWlCQSxXQUFPLElBQVAsQ0FuQlM7RUFBQSxDQUFiOztBQUFBLGtCQXNCQSxLQUFBLEdBQU8sU0FBQSxHQUFBO1dBQ0gsSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBVixDQUFnQixJQUFDLENBQUEsSUFBSSxDQUFDLE1BQXRCLENBQ0ksQ0FBQyxJQURMLENBQ1U7QUFBQSxNQUFFLENBQUEsRUFBRyxJQUFDLENBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFiLEdBQWlCLENBQXRCO0tBRFYsRUFDcUMsRUFEckMsRUFDeUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FEbEUsRUFDeUUsS0FEekUsRUFDZ0YsQ0FEaEYsRUFDbUYsQ0FEbkYsRUFDc0YsSUFEdEYsQ0FFSSxDQUFDLEtBRkwsQ0FBQSxFQURHO0VBQUEsQ0F0QlAsQ0FBQTs7QUFBQSxrQkE0QkEsTUFBQSxHQUFRLFNBQUMsQ0FBRCxFQUFJLENBQUosR0FBQTtBQUVKLElBQUEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxDQUFULEdBQWEsQ0FBYixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsT0FBTyxDQUFDLENBQVQsR0FBYSxDQURiLENBQUE7V0FPQSxJQUFDLENBQUEsT0FBTyxDQUFDLEtBQVQsQ0FBZSxJQUFmLEVBQXFCLEdBQXJCLEVBQTBCLElBQTFCLEVBQWdDLENBQWhDLEVBVEk7RUFBQSxDQTVCUixDQUFBOztBQUFBLGtCQXVDQSxHQUFBLEdBQUssU0FBQSxHQUFBO1dBQ0QsSUFBQyxDQUFBLFVBQVUsQ0FBQyxJQUFaLENBQUEsRUFEQztFQUFBLENBdkNMLENBQUE7O0FBQUEsa0JBMENBLElBQUEsR0FBTSxTQUFDLENBQUQsRUFBSSxDQUFKLEdBQUE7QUFHRixJQUFBLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFBLENBQUEsQ0FBQTtXQUVBLElBQUMsQ0FBQSxNQUFELENBQVEsQ0FBUixFQUFXLENBQVgsRUFMRTtFQUFBLENBMUNOLENBQUE7O2VBQUE7O0lBRkosQ0FBQTs7Ozs7QUNBQSxJQUFBLHNEQUFBOztBQUFBLEtBQUEsR0FBUSxPQUFBLENBQVEsU0FBUixDQUFrQixDQUFDLEtBQTNCLENBQUE7O0FBQUEsTUFFQSxHQUFTLE9BQUEsQ0FBUSxVQUFSLENBQW1CLENBQUMsTUFGN0IsQ0FBQTs7QUFBQSxRQUdBLEdBQVcsT0FBQSxDQUFRLFlBQVIsQ0FBcUIsQ0FBQyxRQUhqQyxDQUFBOztBQUFBLEtBS0EsR0FBUSxPQUFBLENBQVEsU0FBUixDQUFrQixDQUFDLEtBTDNCLENBQUE7O0FBQUEsV0FPQSxHQUFjLE9BQUEsQ0FBUSxlQUFSLENBQXdCLENBQUMsV0FQdkMsQ0FBQTs7QUFBQSxNQVNNLENBQUMsTUFBUCxHQUFnQixTQUFBLEdBQUE7U0FJWixNQUFNLENBQUMsSUFBUCxHQUFrQixJQUFBLE1BQU0sQ0FBQyxJQUFQLENBQVksR0FBWixFQUFpQixHQUFqQixFQUFzQixNQUFNLENBQUMsTUFBN0IsRUFBcUMsZ0JBQXJDLEVBQXVELFNBQXZELEVBSk47QUFBQSxDQVRoQixDQUFBOztBQUFBLFNBZUEsR0FDSTtBQUFBLEVBQUEsT0FBQSxFQUFTLFNBQUEsR0FBQTtBQUdMLElBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFWLENBQWdCLFlBQWhCLEVBQThCLHNCQUE5QixDQUFBLENBQUE7QUFBQSxJQUNBLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBVixDQUFnQixPQUFoQixFQUF5QixzQkFBekIsQ0FEQSxDQUFBO0FBQUEsSUFFQSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQVYsQ0FBZ0IsU0FBaEIsRUFBMkIsc0JBQTNCLENBRkEsQ0FBQTtBQUFBLElBR0EsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFWLENBQWdCLFVBQWhCLEVBQTRCLHNCQUE1QixDQUhBLENBQUE7QUFBQSxJQU1BLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVixDQUFzQixRQUF0QixFQUFnQyx1QkFBaEMsRUFBeUQsRUFBekQsRUFBNkQsRUFBN0QsQ0FOQSxDQUFBO0FBQUEsSUFTQSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVYsQ0FBc0IsT0FBdEIsRUFBK0Isc0JBQS9CLEVBQXVELEVBQXZELEVBQTJELEVBQTNELENBVEEsQ0FBQTtBQUFBLElBWUEsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFWLENBQWdCLE9BQWhCLEVBQXlCLHNCQUF6QixDQVpBLENBQUE7QUFBQSxJQWVBLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBVixDQUFnQixZQUFoQixFQUE4QixzQkFBOUIsQ0FmQSxDQUFBO1dBcUJBLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBVixDQUFnQixTQUFoQixFQUEyQiwwQkFBM0IsRUF4Qks7RUFBQSxDQUFUO0FBQUEsRUEyQkEsTUFBQSxFQUFRLFNBQUEsR0FBQTtBQU9KLFFBQUEsNENBQUE7QUFBQSxJQUFBLGFBQUEsR0FBZ0IsR0FBaEIsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLGFBQUQsR0FBaUIsSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBVixDQUFBLENBRGpCLENBQUE7QUFBQSxJQUVBLElBQUMsQ0FBQSxhQUFhLENBQUMsVUFBZixHQUE0QixJQUY1QixDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsYUFBYSxDQUFDLGVBQWYsR0FBaUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUhoRCxDQUFBO0FBQUEsSUFLQSxJQUFDLENBQUEsYUFBYSxDQUFDLGNBQWYsQ0FBOEIsYUFBOUIsRUFBNkMsVUFBN0MsRUFBeUQsQ0FBekQsQ0FMQSxDQUFBO0FBQUEsSUFRQSxJQUFDLENBQUEsYUFBRCxHQUFpQixDQVJqQixDQUFBO0FBQUEsSUFZQSxJQUFDLENBQUEsR0FBRCxHQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBVCxDQUFBLENBWlAsQ0FBQTtBQUFBLElBZUEsSUFBQyxDQUFBLEdBQUcsQ0FBQyxlQUFMLENBQXFCLE9BQXJCLENBZkEsQ0FBQTtBQUFBLElBb0JBLFNBQUEsR0FBWSxFQXBCWixDQUFBO0FBQUEsSUFxQkEsVUFBQSxHQUFhLEVBckJiLENBQUE7QUFBQSxJQXlCQSxNQUFBLEdBQVMsSUFBQyxDQUFBLEdBQUcsQ0FBQyxNQUFMLENBQVksUUFBWixFQUFzQixTQUF0QixFQUFpQyxVQUFqQyxFQUE2QyxFQUE3QyxFQUFpRCxFQUFqRCxDQXpCVCxDQUFBO0FBQUEsSUE4QkEsTUFBTSxDQUFDLFdBQVAsQ0FBQSxDQTlCQSxDQUFBO0FBQUEsSUFrQ0EsSUFBQyxDQUFBLFlBQUQsR0FBZ0IsTUFsQ2hCLENBQUE7QUFBQSxJQW1DQSxJQUFDLENBQUEsV0FBRCxHQUFlLENBbkNmLENBQUE7QUFBQSxJQXNDQSxJQUFDLENBQUEsR0FBRyxDQUFDLElBQUwsQ0FBVSxJQUFDLENBQUEsV0FBWCxFQUF3QixDQUF4QixFQUEyQixDQUEzQixFQUE4QixTQUE5QixFQUF5QyxVQUF6QyxFQUFxRCxJQUFDLENBQUEsWUFBdEQsQ0F0Q0EsQ0FBQTtBQUFBLElBeUNBLElBQUMsQ0FBQSxXQUFELEdBQWUsQ0F6Q2YsQ0FBQTtBQUFBLElBMENBLElBQUMsQ0FBQSxHQUFHLENBQUMsSUFBTCxDQUFVLElBQUMsQ0FBQSxXQUFYLEVBQXdCLEVBQXhCLEVBQTRCLEVBQTVCLEVBQWdDLEVBQWhDLEVBQW9DLEVBQXBDLEVBQXdDLElBQUMsQ0FBQSxZQUF6QyxDQTFDQSxDQUFBO0FBQUEsSUE2Q0EsSUFBQyxDQUFBLElBQUksQ0FBQyxZQUFOLEdBQXFCO0FBQUEsTUFDakIsT0FBQSxFQUFTLElBQUMsQ0FBQSxHQURPO0FBQUEsTUFFakIsWUFBQSxFQUFjLElBQUMsQ0FBQSxZQUZFO0tBN0NyQixDQUFBO0FBQUEsSUFxREEsSUFBQyxDQUFBLEdBQUcsQ0FBQyxZQUFMLENBQWtCLENBQUUsQ0FBRixDQUFsQixFQUF5QixJQUF6QixFQUErQixRQUEvQixDQXJEQSxDQUFBO0FBQUEsSUEyREEsSUFBQyxDQUFBLE1BQUQsR0FBYyxJQUFBLE1BQUEsQ0FBTyxJQUFQLENBM0RkLENBQUE7QUFBQSxJQThEQSxJQUFDLENBQUEsS0FBRCxHQUFhLElBQUEsS0FBQSxDQUFNLElBQU4sRUFBWSxJQUFDLENBQUEsTUFBYixDQTlEYixDQUFBO0FBQUEsSUFrRUEsSUFBQyxDQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBYixDQUFvQixJQUFDLENBQUEsTUFBckIsRUFBNkIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxvQkFBM0MsQ0FsRUEsQ0FBQTtBQUFBLElBMEVBLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBTixHQUFrQixJQUFBLEtBQUEsQ0FBTSxJQUFDLENBQUEsSUFBUCxDQTFFbEIsQ0FBQTtBQUFBLElBNkVBLElBQUMsQ0FBQSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQVgsR0FBNEIsSUE3RTVCLENBQUE7QUFBQSxJQThFQSxJQUFDLENBQUEsVUFBRCxHQUFjLElBQUMsQ0FBQSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQVYsQ0FDVixFQURVLEVBQ04sRUFETSxFQUNGLEVBREUsRUFDRTtBQUFBLE1BQUUsSUFBQSxFQUFNLFlBQVI7QUFBQSxNQUFzQixJQUFBLEVBQU0sU0FBNUI7S0FERixDQTlFZCxDQUFBO1dBaUZBLElBQUMsQ0FBQSxVQUFVLENBQUMsYUFBWixHQUE0QixLQXhGeEI7RUFBQSxDQTNCUjtBQUFBLEVBdUhBLE1BQUEsRUFBUSxTQUFBLEdBQUE7QUFDSixJQUFBLElBQUMsQ0FBQSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFyQixDQUE2QixJQUFDLENBQUEsTUFBOUIsRUFBc0MsSUFBQyxDQUFBLFlBQXZDLENBQUEsQ0FBQTtBQUFBLElBR0EsSUFBQyxDQUFBLFVBQVUsQ0FBQyxPQUFaLENBQW9CLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FBcEIsQ0FIQSxDQUFBO0FBQUEsSUFNQSxJQUFDLENBQUEsYUFBRCxJQUFrQixJQUFDLENBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxPQU43QixDQUFBO0FBT0EsSUFBQSxJQUFJLElBQUMsQ0FBQSxhQUFELElBQWtCLENBQXRCO0FBQ0ksTUFBQSxJQUFDLENBQUEsYUFBRCxHQUFpQixJQUFDLENBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFWLENBQXlCLENBQXpCLEVBQTRCLEVBQTVCLENBQWpCLENBQUE7YUFDQSxJQUFDLENBQUEsaUJBQUQsQ0FBQSxFQUZKO0tBUkk7RUFBQSxDQXZIUjtBQUFBLEVBeUpBLGlCQUFBLEVBQW1CLFNBQUEsR0FBQTtBQUNmLFFBQUEsc0RBQUE7QUFBQSxJQUFBLFFBQUEsR0FBVyxJQUFDLENBQUEsYUFBYSxDQUFDLFlBQWYsQ0FBQSxDQUFYLENBQUE7QUFFQSxJQUFBLElBQUksUUFBSjtBQUNJLE1BQUEsRUFBQSxHQUFLLENBQUwsQ0FBQTtBQUFBLE1BQ0EsRUFBQSxHQUFLLENBREwsQ0FBQTtBQUFBLE1BRUEsSUFBQSxHQUFPLEVBRlAsQ0FBQTtBQUFBLE1BR0EsSUFBQSxHQUFPLEVBSFAsQ0FBQTtBQUlBLGFBQU8sRUFBQSxHQUFLLElBQUwsSUFBYSxFQUFBLEdBQUssQ0FBQSxJQUFsQixJQUEyQixFQUFBLEdBQUssSUFBaEMsSUFBd0MsRUFBQSxHQUFLLENBQUEsSUFBcEQsR0FBQTtBQUNJLFFBQUEsRUFBQSxHQUFLLElBQUMsQ0FBQSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQVYsQ0FBa0IsQ0FBQSxJQUFsQixFQUF5QixJQUF6QixDQUFMLENBQUE7QUFBQSxRQUNBLEVBQUEsR0FBSyxJQUFDLENBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFWLENBQWtCLENBQUEsSUFBbEIsRUFBeUIsSUFBekIsQ0FETCxDQURKO01BQUEsQ0FKQTtBQUFBLE1BUUEsRUFBQSxHQUFRLEVBQUEsR0FBSyxDQUFSLEdBQWUsQ0FBZixHQUFzQixJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQVJ2QyxDQUFBO0FBQUEsTUFTQSxFQUFBLEdBQVEsRUFBQSxHQUFLLENBQVIsR0FBZSxDQUFmLEdBQXNCLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BVHZDLENBQUE7QUFBQSxNQVdBLFNBQUEsR0FBWSxJQUFDLENBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFWLENBQWUsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUFmLENBWFosQ0FBQTtBQUFBLE1BWUEsRUFBQSxHQUFRLFNBQUEsS0FBYSxHQUFoQixHQUF5QixJQUFDLENBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFWLENBQWtCLENBQWxCLEVBQXFCLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQWpDLENBQXpCLEdBQXNFLEVBWjNFLENBQUE7QUFBQSxNQWFBLEVBQUEsR0FBUSxTQUFBLEtBQWEsR0FBaEIsR0FBeUIsSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBVixDQUFrQixDQUFsQixFQUFxQixJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFqQyxDQUF6QixHQUF1RSxFQWI1RSxDQUFBO0FBQUEsTUFnQkEsUUFBUSxDQUFDLEtBQVQsQ0FBZSxFQUFmLEVBQW1CLEVBQW5CLENBaEJBLENBQUE7QUFBQSxNQWlCQSxRQUFRLENBQUMsTUFBVCxDQUFBLENBakJBLENBQUE7QUFBQSxNQW9CQSxLQUFBLEdBQVEsSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVixDQUFzQixHQUF0QixFQUEyQixHQUEzQixDQXBCUixDQUFBO0FBQUEsTUFzQkEsUUFBUSxDQUFDLEtBQVQsR0FBaUIsS0F0QmpCLENBQUE7QUFBQSxNQXdCQSxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUF2QixDQUE2QixDQUE3QixFQUFnQyxDQUFoQyxDQXhCQSxDQUFBO0FBQUEsTUF5QkEsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBM0IsQ0FBaUMsQ0FBakMsRUFBb0MsQ0FBcEMsQ0F6QkEsQ0FBQTtBQUFBLE1BNEJBLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQXZCLEdBQTJCLEVBNUIzQixDQUFBO0FBQUEsTUE2QkEsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBdkIsR0FBMkIsRUE3QjNCLENBQUE7QUFBQSxNQWdDQSxRQUFRLENBQUMsUUFBVCxHQUFvQixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVosQ0FBcUIsSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBVixDQUFBLENBQXJCLENBaENwQixDQUFBO0FBQUEsTUFtQ0EsUUFBUSxDQUFDLEtBQVQsR0FBaUIsQ0FuQ2pCLENBQUE7QUFBQSxNQXNDQSxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQWhCLENBQXNCLEdBQXRCLEVBQTJCLEdBQTNCLENBdENBLENBQUE7QUFBQSxNQTRDQSxRQUFRLENBQUMsZ0JBQVQsR0FBNEIsSUE1QzVCLENBQUE7YUE2Q0EsUUFBUSxDQUFDLGVBQVQsR0FBMkIsS0E5Qy9CO0tBSGU7RUFBQSxDQXpKbkI7QUFBQSxFQTRNQSxhQUFBLEVBQWUsU0FBQSxHQUFBO0FBQ1gsUUFBQSxNQUFBO0FBQUEsSUFBQSxNQUFBLEdBQVMsRUFBVCxDQUFBO0FBQUEsSUFDQSxNQUFBLElBQVUsSUFBQyxDQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBWCxHQUFpQixNQUFqQixHQUEwQixJQURwQyxDQUFBO0FBQUEsSUFFQSxNQUFBLElBQVUsUUFBQSxHQUFXLElBQUMsQ0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQXhCLEdBQStCLElBRnpDLENBQUE7QUFBQSxJQUdBLE1BQUEsSUFBVSxJQUFDLENBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFiLENBQUEsQ0FIVixDQUFBO0FBSUEsV0FBTyxNQUFQLENBTFc7RUFBQSxDQTVNZjtDQWhCSixDQUFBOzs7OztBQ0FBLElBQUEsc0RBQUE7RUFBQTs7aVNBQUE7O0FBQUEsZ0JBQUEsR0FBbUIsT0FBQSxDQUFRLG9CQUFSLENBQTZCLENBQUMsZ0JBQWpELENBQUE7O0FBQUEsV0FFQSxHQUFjLE9BQUEsQ0FBUSxlQUFSLENBQXdCLENBQUMsV0FGdkMsQ0FBQTs7QUFBQSxTQUdBLEdBQVksT0FBQSxDQUFRLGFBQVIsQ0FBc0IsQ0FBQyxTQUhuQyxDQUFBOztBQUFBLFlBSUEsR0FBZSxPQUFBLENBQVEsZ0JBQVIsQ0FBeUIsQ0FBQyxZQUp6QyxDQUFBOztBQUFBLE9BT2EsQ0FBQztBQUVWLDJCQUFBLENBQUE7O0FBQUEsbUJBQUEsS0FBQSxHQUFPLEdBQVAsQ0FBQTs7QUFFYSxFQUFBLGdCQUFFLElBQUYsR0FBQTtBQUdULFFBQUEsSUFBQTtBQUFBLElBSFUsSUFBQyxDQUFBLE9BQUEsSUFHWCxDQUFBO0FBQUEsMkNBQUEsQ0FBQTtBQUFBLElBQUEsQ0FBQSxHQUFJLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQWhCLENBQUE7QUFBQSxJQUNBLENBQUEsR0FBSSxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQURoQixDQUFBO0FBQUEsSUFJQSx3Q0FBTSxJQUFDLENBQUEsSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsUUFBbkIsQ0FKQSxDQUFBO0FBQUEsSUFPQSxJQUFDLENBQUEsTUFBTSxDQUFDLEtBQVIsQ0FBYyxHQUFkLEVBQW1CLEdBQW5CLENBUEEsQ0FBQTtBQUFBLElBVUEsSUFBQyxDQUFBLFVBQVUsQ0FBQyxHQUFaLENBQWdCLE1BQWhCLEVBQXdCLENBQUMsQ0FBRCxDQUF4QixDQVZBLENBQUE7QUFBQSxJQVdBLElBQUMsQ0FBQSxVQUFVLENBQUMsR0FBWixDQUFnQixNQUFoQixFQUF3QixDQUFDLENBQUQsQ0FBeEIsQ0FYQSxDQUFBO0FBQUEsSUFjQSxJQUFDLENBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFkLENBQXFCLElBQXJCLEVBQXdCLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBdkMsQ0FkQSxDQUFBO0FBQUEsSUFpQkEsSUFBQyxDQUFBLFVBQUQsR0FBa0IsSUFBQSxnQkFBQSxDQUFpQixJQUFDLENBQUEsSUFBbEIsRUFBd0IsSUFBeEIsQ0FqQmxCLENBQUE7QUFBQSxJQW9CQSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVQsQ0FBa0IsSUFBbEIsQ0FwQkEsQ0FBQTtBQUFBLElBNEJBLElBQUMsQ0FBQSxLQUFELEdBQVMsQ0FDRCxJQUFBLFdBQUEsQ0FBWSxJQUFDLENBQUEsSUFBYixFQUFtQixJQUFuQixDQURDLEVBRUQsSUFBQSxZQUFBLENBQWEsSUFBQyxDQUFBLElBQWQsRUFBb0IsSUFBcEIsQ0FGQyxFQUdELElBQUEsU0FBQSxDQUFVLElBQUMsQ0FBQSxJQUFYLEVBQWlCLElBQWpCLENBSEMsQ0E1QlQsQ0FBQTtBQUFBLElBaUNBLElBQUMsQ0FBQSxRQUFELENBQUEsQ0FqQ0EsQ0FBQTtBQW1DQSxXQUFPLElBQVAsQ0F0Q1M7RUFBQSxDQUZiOztBQUFBLG1CQTJDQSxNQUFBLEdBQVEsU0FBQSxHQUFBO0FBR0osSUFBQSxJQUFDLENBQUEsVUFBVSxDQUFDLE1BQVosQ0FBQSxDQUFBLENBQUE7QUFHQSxJQUFBLElBQUcsaUJBQUg7YUFDSSxJQUFDLENBQUEsSUFBSSxDQUFDLE1BQU4sQ0FBQSxFQURKO0tBTkk7RUFBQSxDQTNDUixDQUFBOztBQUFBLG1CQXFEQSxRQUFBLEdBQVUsU0FBQSxHQUFBO0FBSU4sSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFKO0FBQ0ksTUFBQSxJQUFDLENBQUEsSUFBSSxDQUFDLFFBQU4sQ0FBQSxDQUFBLENBREo7S0FBQTtBQUFBLElBSUEsSUFBQyxDQUFBLElBQUQsR0FBUSxJQUFDLENBQUEsS0FBSyxDQUFDLEdBQVAsQ0FBQSxDQUpSLENBQUE7QUFPQSxJQUFBLElBQUcsSUFBQyxDQUFBLElBQUo7QUFDSSxNQUFBLElBQUMsQ0FBQSxLQUFLLENBQUMsT0FBUCxDQUFlLElBQUMsQ0FBQSxJQUFoQixDQUFBLENBQUE7YUFFQSxJQUFDLENBQUEsSUFBSSxDQUFDLE1BQU4sQ0FBQSxFQUhKO0tBWE07RUFBQSxDQXJEVixDQUFBOztnQkFBQTs7R0FGeUIsTUFBTSxDQUFDLE9BUHBDLENBQUE7Ozs7O0FDQUEsSUFBQSxrRkFBQTs7QUFBQSxPQUFhLENBQUM7QUFFViw2QkFBQSxjQUFBLEdBQWdCO0FBQUEsSUFDWixNQUFBLEVBQVE7QUFBQSxNQUNKLEVBQUEsRUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLENBRGhCO0FBQUEsTUFFSixJQUFBLEVBQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUZsQjtBQUFBLE1BR0osSUFBQSxFQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FIbEI7QUFBQSxNQUlKLEtBQUEsRUFBTyxNQUFNLENBQUMsUUFBUSxDQUFDLENBSm5CO0tBREk7QUFBQSxJQU9aLE1BQUEsRUFBUTtBQUFBLE1BQ0osRUFBQSxFQUFJLEdBREE7QUFBQSxNQUVKLElBQUEsRUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLENBRmxCO0FBQUEsTUFHSixJQUFBLEVBQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUhsQjtBQUFBLE1BSUosS0FBQSxFQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FKbkI7S0FQSTtHQUFoQixDQUFBOztBQWdCYSxFQUFBLDBCQUFFLElBQUYsRUFBUyxNQUFULEdBQUE7QUFDVCxJQURVLElBQUMsQ0FBQSxPQUFBLElBQ1gsQ0FBQTtBQUFBLElBRGlCLElBQUMsQ0FBQSxTQUFBLE1BQ2xCLENBQUE7QUFBQSxpREFBQSxDQUFBO0FBQUEsSUFBQSxJQUFDLENBQUEsT0FBRCxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGdCQUFwQixDQUFBLENBQVgsQ0FBQTtBQUFBLElBQ0EsSUFBQyxDQUFBLFNBQUQsQ0FBVyxRQUFYLENBREEsQ0FEUztFQUFBLENBaEJiOztBQUFBLDZCQW9CQSxTQUFBLEdBQVcsU0FBQyxJQUFELEdBQUE7QUFDUCxJQUFBLElBQUcsaUNBQUg7YUFDSSxJQUFDLENBQUEsYUFBRCxHQUFpQixJQUFDLENBQUEsY0FBZSxDQUFBLElBQUEsRUFEckM7S0FETztFQUFBLENBcEJYLENBQUE7O0FBQUEsNkJBd0JBLE1BQUEsR0FBUSxTQUFBLEdBQUE7QUFHSixJQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUF0QixHQUEwQixDQUExQixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBdEIsR0FBMEIsQ0FEMUIsQ0FBQTtBQUlBLElBQUEsSUFBRyxJQUFDLENBQUEsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFkLElBQXdCLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFyQixDQUE0QixJQUFDLENBQUEsYUFBYSxDQUFDLElBQTNDLENBQTNCO0FBQ0ksTUFBQSxJQUFDLENBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBdEIsR0FBMEIsQ0FBQSxDQUFBLEdBQUssSUFBQyxDQUFBLE1BQU0sQ0FBQyxLQUF2QyxDQURKO0tBQUEsTUFFSyxJQUFHLElBQUMsQ0FBQSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQWYsSUFBeUIsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQXJCLENBQTRCLElBQUMsQ0FBQSxhQUFhLENBQUMsS0FBM0MsQ0FBNUI7QUFDRCxNQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUF0QixHQUEwQixJQUFDLENBQUEsTUFBTSxDQUFDLEtBQWxDLENBREM7S0FOTDtBQVVBLElBQUEsSUFBRyxJQUFDLENBQUEsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFaLElBQXNCLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFyQixDQUE0QixJQUFDLENBQUEsYUFBYSxDQUFDLEVBQTNDLENBQXpCO0FBQ0ksTUFBQSxJQUFDLENBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBdEIsR0FBMEIsQ0FBQSxDQUFBLEdBQUssSUFBQyxDQUFBLE1BQU0sQ0FBQyxLQUF2QyxDQURKO0tBQUEsTUFFSyxJQUFHLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQWQsSUFBd0IsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQXJCLENBQTRCLElBQUMsQ0FBQSxhQUFhLENBQUMsSUFBM0MsQ0FBM0I7QUFDRCxNQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUF0QixHQUEwQixJQUFDLENBQUEsTUFBTSxDQUFDLEtBQWxDLENBREM7S0FaTDtBQWVBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBckIsQ0FBa0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFsRCxFQUE0RCxFQUE1RCxDQUFIO2FBQ0ksSUFBQyxDQUFBLE1BQU0sQ0FBQyxRQUFSLENBQUEsRUFESjtLQWxCSTtFQUFBLENBeEJSLENBQUE7OzBCQUFBOztJQUZKLENBQUE7Ozs7O0FDQ0EsSUFBQSxrRkFBQTs7QUFBQSxPQUFhLENBQUM7QUFHVixzQkFBQSxJQUFBLEdBQU0sT0FBTixDQUFBOztBQUFBLHNCQUdBLGFBQUEsR0FBZSxDQUhmLENBQUE7O0FBQUEsc0JBTUEsT0FBQSxHQUFTLElBTlQsQ0FBQTs7QUFRYSxFQUFBLG1CQUFFLElBQUYsRUFBUyxNQUFULEdBQUE7QUFHVCxJQUhVLElBQUMsQ0FBQSxPQUFBLElBR1gsQ0FBQTtBQUFBLElBSGlCLElBQUMsQ0FBQSxTQUFBLE1BR2xCLENBQUE7QUFBQSwyQ0FBQSxDQUFBO0FBQUEsSUFBQSxJQUFDLENBQUEsR0FBRCxHQUFPLElBQUMsQ0FBQSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQVYsQ0FBaUIsRUFBakIsRUFBcUIsSUFBQyxDQUFBLElBQUksQ0FBQyxNQUFOLEdBQWEsQ0FBbEMsRUFBcUMsT0FBckMsQ0FBUCxDQUFBO0FBQUEsSUFHQSxJQUFDLENBQUEsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFaLENBQWtCLEdBQWxCLEVBQXVCLEdBQXZCLENBSEEsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLEdBQUcsQ0FBQyxPQUFMLEdBQWUsS0FMZixDQUFBO0FBQUEsSUFRQSxJQUFDLENBQUEsU0FBRCxHQUFhLElBQUMsQ0FBQSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQVYsQ0FBaUIsRUFBakIsRUFBcUIsSUFBQyxDQUFBLElBQUksQ0FBQyxNQUFOLEdBQWEsQ0FBbEMsRUFBcUMsWUFBckMsQ0FSYixDQUFBO0FBQUEsSUFTQSxJQUFDLENBQUEsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFsQixDQUF3QixHQUF4QixFQUE2QixHQUE3QixDQVRBLENBQUE7QUFBQSxJQVdBLElBQUMsQ0FBQSxXQUFELEdBQWUsQ0FYZixDQUFBO0FBQUEsSUFZQSxJQUFDLENBQUEsR0FBRCxHQUFPLElBQUMsQ0FBQSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BWjFCLENBQUE7QUFBQSxJQWFBLElBQUMsQ0FBQSxZQUFELEdBQWdCLElBQUMsQ0FBQSxJQUFJLENBQUMsWUFBWSxDQUFDLFlBYm5DLENBQUE7QUFlQSxXQUFPLElBQVAsQ0FsQlM7RUFBQSxDQVJiOztBQUFBLHNCQTRCQSxXQUFBLEdBQWEsU0FBQSxHQUFBLENBNUJiLENBQUE7O0FBQUEsc0JBK0JBLFdBQUEsR0FBYSxTQUFBLEdBQUEsQ0EvQmIsQ0FBQTs7QUFBQSxzQkFrQ0EsZUFBQSxHQUFpQixTQUFBLEdBQUEsQ0FsQ2pCLENBQUE7O0FBQUEsc0JBc0NBLFFBQUEsR0FBVSxTQUFDLENBQUQsRUFBSSxDQUFKLEdBQUE7QUFFTixJQUFBLElBQU8sb0JBQVA7QUFDSSxNQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVksNkNBQVosQ0FBQSxDQUFBO0FBQ0EsWUFBQSxDQUZKO0tBQUE7V0FJQSxJQUFDLENBQUEsYUFBRCxHQUFpQixFQU5YO0VBQUEsQ0F0Q1YsQ0FBQTs7QUFBQSxzQkErQ0EsU0FBQSxHQUFXLFNBQUMsQ0FBRCxFQUFJLENBQUosR0FBQTtBQUVQLElBQUEsSUFBTyxvQkFBUDtNQUNJLE9BQU8sQ0FBQyxHQUFSLENBQVksOENBQVosRUFESjtLQUZPO0VBQUEsQ0EvQ1gsQ0FBQTs7QUFBQSxzQkF5REEscUJBQUEsR0FBdUIsU0FBQyxDQUFELEVBQUksQ0FBSixHQUFBLENBekR2QixDQUFBOztBQUFBLHNCQTREQSxNQUFBLEdBQVEsU0FBQSxHQUFBO0FBR0osUUFBQSxnQkFBQTtBQUFBLElBQUEsSUFBQyxDQUFBLEdBQUcsQ0FBQyxDQUFMLEdBQVMsSUFBQyxDQUFBLE1BQU0sQ0FBQyxDQUFqQixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsR0FBRyxDQUFDLENBQUwsR0FBUyxJQUFDLENBQUEsTUFBTSxDQUFDLENBRGpCLENBQUE7QUFBQSxJQUlBLElBQUMsQ0FBQSxTQUFTLENBQUMsQ0FBWCxHQUFlLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLE1BQTFCLEdBQW1DLEVBQTlDLENBQUEsR0FBb0QsRUFBcEQsR0FBeUQsRUFKeEUsQ0FBQTtBQUFBLElBS0EsSUFBQyxDQUFBLFNBQVMsQ0FBQyxDQUFYLEdBQWUsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBMUIsR0FBbUMsRUFBOUMsQ0FBQSxHQUFvRCxFQUFwRCxHQUF5RCxFQUx4RSxDQUFBO0FBQUEsSUFlQSxPQUFBLEdBQVUsSUFBQyxDQUFBLFlBQVksQ0FBQyxRQUFkLENBQXVCLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLE1BQWhELENBQUEsR0FBMEQsRUFmcEUsQ0FBQTtBQUFBLElBZ0JBLE9BQUEsR0FBVSxJQUFDLENBQUEsWUFBWSxDQUFDLFFBQWQsQ0FBdUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBaEQsQ0FBQSxHQUEwRCxFQWhCcEUsQ0FBQTtBQWtCQSxJQUFBLElBQUksSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQTdCO0FBQ0ksTUFBQSxJQUFDLENBQUEsTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFuQixDQUF3QixNQUF4QixDQUFBLENBQUE7QUFFQSxNQUFBLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBcEIsQ0FBMkIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUEzQyxDQUFKO0FBQ0ksUUFBQSxJQUFDLENBQUEsV0FBRCxHQUFlLElBQUMsQ0FBQSxHQUFHLENBQUMsT0FBTCxDQUFhLElBQUMsQ0FBQSxZQUFZLENBQUMsUUFBZCxDQUF1QixPQUF2QixDQUFiLEVBQThDLElBQUMsQ0FBQSxZQUFZLENBQUMsUUFBZCxDQUF1QixPQUF2QixDQUE5QyxDQUE4RSxDQUFDLEtBQTlGLENBREo7T0FBQSxNQUFBO0FBR0ksUUFBQSxJQUFJLElBQUMsQ0FBQSxHQUFHLENBQUMsT0FBTCxDQUFhLElBQUMsQ0FBQSxZQUFZLENBQUMsUUFBZCxDQUF1QixPQUF2QixDQUFiLEVBQThDLElBQUMsQ0FBQSxZQUFZLENBQUMsUUFBZCxDQUF1QixPQUF2QixDQUE5QyxDQUE4RSxDQUFDLEtBQS9FLEtBQXdGLElBQUMsQ0FBQSxXQUE3RjtBQUNJLFVBQUEsSUFBQyxDQUFBLEdBQUcsQ0FBQyxPQUFMLENBQWEsSUFBQyxDQUFBLFdBQWQsRUFBMkIsSUFBQyxDQUFBLFlBQVksQ0FBQyxRQUFkLENBQXVCLE9BQXZCLENBQTNCLEVBQTRELElBQUMsQ0FBQSxZQUFZLENBQUMsUUFBZCxDQUF1QixPQUF2QixDQUE1RCxDQUFBLENBQUE7QUFBQSxVQUNBLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQVosQ0FBaUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBMUMsRUFBa0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBM0UsQ0FEQSxDQURKO1NBSEo7T0FISjtLQUFBLE1BQUE7QUFVSSxNQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsVUFBVSxDQUFDLElBQW5CLENBQXdCLE1BQXhCLENBQUEsQ0FWSjtLQWxCQTtBQThCQSxJQUFBLElBQUcsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQXJCLENBQWtDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBbEQsRUFBcUQsRUFBckQsQ0FBSDtBQUNJLE1BQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQVosQ0FBa0IsSUFBQyxDQUFBLFdBQUQsR0FBZSxDQUFqQyxFQUFvQyxDQUFwQyxFQUF1QyxDQUF2QyxDQUFmLENBREo7S0E5QkE7QUFpQ0EsSUFBQSxJQUFHLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFyQixDQUFrQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQWxELEVBQXFELEVBQXJELENBQUg7YUFDSSxJQUFDLENBQUEsV0FBRCxHQUFlLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBWixDQUFrQixJQUFDLENBQUEsV0FBRCxHQUFlLENBQWpDLEVBQW9DLENBQXBDLEVBQXVDLENBQXZDLEVBRG5CO0tBcENJO0VBQUEsQ0E1RFIsQ0FBQTs7QUFBQSxzQkFvR0EsYUFBQSxHQUFlLFNBQUEsR0FBQTtBQUNYLFFBQUEsTUFBQTtBQUFBLElBQUEsTUFBQSxHQUFTLEVBQVQsQ0FBQTtBQUFBLElBQ0EsTUFBQSxJQUFVLFVBQUEsR0FBYSxJQUFDLENBQUEsV0FBZCxHQUE0QixJQUR0QyxDQUFBO0FBRUEsV0FBTyxNQUFQLENBSFc7RUFBQSxDQXBHZixDQUFBOztBQUFBLHNCQXlHQSxNQUFBLEdBQVEsU0FBQSxHQUFBO1dBQ0osSUFBQyxDQUFBLFNBQVMsQ0FBQyxNQUFYLENBQUEsRUFESTtFQUFBLENBekdSLENBQUE7O0FBQUEsc0JBNEdBLFFBQUEsR0FBVSxTQUFBLEdBQUE7V0FDTixJQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsQ0FBQSxFQURNO0VBQUEsQ0E1R1YsQ0FBQTs7bUJBQUE7O0lBSEosQ0FBQTs7Ozs7QUNBQSxJQUFBLGtGQUFBOztBQUFBLE9BQWEsQ0FBQztBQUdWLHdCQUFBLElBQUEsR0FBTSxlQUFOLENBQUE7O0FBQUEsd0JBR0EsVUFBQSxHQUFZLEdBSFosQ0FBQTs7QUFBQSx3QkFJQSxZQUFBLEdBQWMsR0FKZCxDQUFBOztBQUFBLHdCQUtBLGlCQUFBLEdBQW1CLEVBTG5CLENBQUE7O0FBQUEsd0JBTUEsZUFBQSxHQUFpQixDQU5qQixDQUFBOztBQUFBLHdCQU9BLGtCQUFBLEdBQW9CLEVBUHBCLENBQUE7O0FBU2EsRUFBQSxxQkFBRSxJQUFGLEVBQVMsTUFBVCxHQUFBO0FBRVQsSUFGVSxJQUFDLENBQUEsT0FBQSxJQUVYLENBQUE7QUFBQSxJQUZpQixJQUFDLENBQUEsU0FBQSxNQUVsQixDQUFBO0FBQUEsMkNBQUEsQ0FBQTtBQUFBLElBQUEsSUFBQyxDQUFBLGVBQUQsR0FBbUIsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFaLENBQXFCLEVBQXJCLENBQW5CLENBQUE7QUFBQSxJQUdBLElBQUMsQ0FBQSxHQUFELEdBQU8sSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBVixDQUFpQixFQUFqQixFQUFxQixJQUFDLENBQUEsSUFBSSxDQUFDLE1BQU4sR0FBYSxDQUFsQyxFQUFxQyxTQUFyQyxDQUhQLENBQUE7QUFBQSxJQU1BLElBQUMsQ0FBQSxHQUFHLENBQUMsT0FBTCxHQUFlLEtBTmYsQ0FBQTtBQUFBLElBU0EsSUFBQyxDQUFBLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBWixDQUFrQixHQUFsQixFQUF1QixHQUF2QixDQVRBLENBQUE7QUFBQSxJQVlBLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FaQSxDQUFBO0FBY0EsV0FBTyxJQUFQLENBaEJTO0VBQUEsQ0FUYjs7QUFBQSx3QkEyQkEsTUFBQSxHQUFRLFNBQUEsR0FBQTtBQUdKLElBQUEsSUFBQyxDQUFBLEdBQUcsQ0FBQyxDQUFMLEdBQVMsSUFBQyxDQUFBLE1BQU0sQ0FBQyxDQUFqQixDQUFBO0FBQUEsSUFDQSxJQUFDLENBQUEsR0FBRyxDQUFDLENBQUwsR0FBUyxJQUFDLENBQUEsTUFBTSxDQUFDLENBRGpCLENBQUE7QUFBQSxJQUlBLElBQUMsQ0FBQSxHQUFHLENBQUMsUUFBTCxHQUFnQixJQUFDLENBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsY0FBckIsQ0FBb0MsSUFBQyxDQUFBLEdBQXJDLENBSmhCLENBQUE7QUFPQSxJQUFBLElBQUcsSUFBQyxDQUFBLGlCQUFELENBQUEsQ0FBSDtBQUNJLE1BQUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBbkIsQ0FBd0IsTUFBeEIsQ0FBQSxDQUFBO2FBQ0EsSUFBQyxDQUFBLFdBQUQsQ0FBQSxFQUZKO0tBQUEsTUFBQTthQUlJLElBQUMsQ0FBQSxNQUFNLENBQUMsVUFBVSxDQUFDLElBQW5CLENBQXdCLE1BQXhCLEVBSko7S0FWSTtFQUFBLENBM0JSLENBQUE7O0FBQUEsd0JBcURBLGlCQUFBLEdBQW1CLFNBQUEsR0FBQTtBQUNmLFFBQUEsb0JBQUE7QUFBQSxJQUFBLFFBQUEsR0FBVyxLQUFYLENBQUE7QUFBQSxJQUdBLFVBQUEsR0FBYSxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBbEIsS0FBNEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxXQUh0RCxDQUFBO0FBT0EsV0FBTyxVQUFQLENBUmU7RUFBQSxDQXJEbkIsQ0FBQTs7QUFBQSx3QkFnRUEsYUFBQSxHQUFlLFNBQUEsR0FBQTtBQUdYLFFBQUEsNkJBQUE7QUFBQSxJQUFBLElBQUMsQ0FBQSxVQUFELEdBQWMsSUFBQyxDQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBVixDQUFBLENBQWQsQ0FBQTtBQUNBO1NBQVMsMkdBQVQsR0FBQTtBQUVJLE1BQUEsTUFBQSxHQUFTLElBQUMsQ0FBQSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQVYsQ0FBaUIsQ0FBakIsRUFBb0IsQ0FBcEIsRUFBdUIsU0FBdkIsQ0FBVCxDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsVUFBVSxDQUFDLEdBQVosQ0FBZ0IsTUFBaEIsQ0FEQSxDQUFBO0FBQUEsTUFLQSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQWQsQ0FBb0IsR0FBcEIsRUFBeUIsR0FBekIsQ0FMQSxDQUFBO0FBQUEsTUFRQSxJQUFDLENBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFkLENBQXFCLE1BQXJCLEVBQTZCLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBNUMsQ0FSQSxDQUFBO0FBQUEsTUFXQSxNQUFNLENBQUMsS0FBUCxHQUFlLENBWGYsQ0FBQTtBQUFBLG9CQWNBLE1BQU0sQ0FBQyxJQUFQLENBQUEsRUFkQSxDQUZKO0FBQUE7b0JBSlc7RUFBQSxDQWhFZixDQUFBOztBQUFBLHdCQXVGQSxXQUFBLEdBQWEsU0FBQSxHQUFBO0FBS1QsUUFBQSxNQUFBO0FBQUEsSUFBQSxJQUFHLElBQUMsQ0FBQSxnQkFBRCxLQUFxQixNQUF4QjtBQUNJLE1BQUEsSUFBQyxDQUFBLGdCQUFELEdBQW9CLENBQXBCLENBREo7S0FBQTtBQUVBLElBQUEsSUFBRyxJQUFDLENBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFYLEdBQWlCLElBQUMsQ0FBQSxnQkFBbEIsR0FBcUMsSUFBQyxDQUFBLFVBQXpDO0FBQ0ksWUFBQSxDQURKO0tBRkE7QUFBQSxJQUlBLElBQUMsQ0FBQSxnQkFBRCxHQUFvQixJQUFDLENBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUovQixDQUFBO0FBQUEsSUFPQSxNQUFBLEdBQVMsSUFBQyxDQUFBLFVBQVUsQ0FBQyxZQUFaLENBQUEsQ0FQVCxDQUFBO0FBVUEsSUFBQSxJQUFHLE1BQUEsS0FBVSxJQUFWLElBQWtCLE1BQUEsS0FBVSxNQUEvQjtBQUNJLFlBQUEsQ0FESjtLQVZBO0FBQUEsSUFlQSxNQUFNLENBQUMsTUFBUCxDQUFBLENBZkEsQ0FBQTtBQUFBLElBcUJBLE1BQU0sQ0FBQyxnQkFBUCxHQUEwQixJQXJCMUIsQ0FBQTtBQUFBLElBc0JBLE1BQU0sQ0FBQyxlQUFQLEdBQXlCLElBdEJ6QixDQUFBO0FBQUEsSUF5QkEsTUFBTSxDQUFDLEtBQVAsQ0FBYSxJQUFDLENBQUEsR0FBRyxDQUFDLENBQWxCLEVBQXFCLElBQUMsQ0FBQSxHQUFHLENBQUMsQ0FBMUIsQ0F6QkEsQ0FBQTtBQUFBLElBMEJBLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUMsQ0FBQSxHQUFHLENBQUMsUUFBTCxHQUFnQixJQUFDLENBQUEsZUExQm5DLENBQUE7QUFBQSxJQThCQSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFyQixHQUF5QixJQUFJLENBQUMsR0FBTCxDQUFTLE1BQU0sQ0FBQyxRQUFQLEdBQWtCLElBQUMsQ0FBQSxlQUE1QixDQUFBLEdBQStDLElBQUMsQ0FBQSxZQTlCekUsQ0FBQTtBQUFBLElBK0JBLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQXJCLEdBQXlCLElBQUksQ0FBQyxHQUFMLENBQVMsTUFBTSxDQUFDLFFBQVAsR0FBa0IsSUFBQyxDQUFBLGVBQTVCLENBQUEsR0FBK0MsSUFBQyxDQUFBLFlBL0J6RSxDQUFBO1dBa0NBLElBQUMsQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQVosQ0FBQSxFQXZDUztFQUFBLENBdkZiLENBQUE7O0FBQUEsd0JBZ0lBLGFBQUEsR0FBZSxTQUFBLEdBQUE7QUFDWCxXQUFPLEVBQVAsQ0FEVztFQUFBLENBaElmLENBQUE7O0FBQUEsd0JBbUlBLE1BQUEsR0FBUSxTQUFBLEdBQUEsQ0FuSVIsQ0FBQTs7QUFBQSx3QkFxSUEsUUFBQSxHQUFVLFNBQUEsR0FBQSxDQXJJVixDQUFBOztxQkFBQTs7SUFISixDQUFBOzs7OztBQ0FBLElBQUEsa0ZBQUE7O0FBQUEsT0FBYSxDQUFDO0FBR1YseUJBQUEsSUFBQSxHQUFNLFVBQU4sQ0FBQTs7QUFBQSx5QkFFQSxRQUFBLEdBQVUsR0FGVixDQUFBOztBQUlhLEVBQUEsc0JBQUUsSUFBRixFQUFTLE1BQVQsR0FBQTtBQUVULElBRlUsSUFBQyxDQUFBLE9BQUEsSUFFWCxDQUFBO0FBQUEsSUFGaUIsSUFBQyxDQUFBLFNBQUEsTUFFbEIsQ0FBQTtBQUFBLDJDQUFBLENBQUE7QUFBQSxJQUFBLElBQUMsQ0FBQSxXQUFELEdBQWUsS0FBZixDQUFBO0FBRUEsV0FBTyxJQUFQLENBSlM7RUFBQSxDQUpiOztBQUFBLHlCQVVBLE1BQUEsR0FBUSxTQUFBLEdBQUE7QUFVSixJQUFBLElBQUcsQ0FBQSxJQUFLLENBQUEsV0FBUjtBQUNJLE1BQUEsSUFBRyxJQUFDLENBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsWUFBekIsQ0FBc0MsSUFBQyxDQUFBLFFBQXZDLENBQUg7QUFDSSxRQUFBLElBQUMsQ0FBQSxNQUFNLENBQUMsVUFBVSxDQUFDLElBQW5CLENBQXdCLE1BQXhCLENBQUEsQ0FBQTtBQUFBLFFBQ0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxDQUFSLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFEckMsQ0FBQTtBQUFBLFFBRUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxDQUFSLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFGckMsQ0FBQTtBQUFBLFFBR0EsSUFBQyxDQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBWixDQUFpQixJQUFDLENBQUEsTUFBTSxDQUFDLENBQXpCLEVBQTRCLElBQUMsQ0FBQSxNQUFNLENBQUMsQ0FBcEMsQ0FIQSxDQUFBO2VBSUEsSUFBQyxDQUFBLFdBQUQsR0FBZSxLQUxuQjtPQURKO0tBQUEsTUFBQTtBQVFJLE1BQUEsSUFBRyxDQUFBLElBQUssQ0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxZQUF6QixDQUFzQyxJQUFDLENBQUEsUUFBdkMsQ0FBUDtBQUNJLFFBQUEsSUFBQyxDQUFBLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBbkIsQ0FBd0IsTUFBeEIsQ0FBQSxDQUFBO2VBQ0EsSUFBQyxDQUFBLFdBQUQsR0FBZSxNQUZuQjtPQVJKO0tBVkk7RUFBQSxDQVZSLENBQUE7O0FBQUEseUJBZ0NBLGFBQUEsR0FBZSxTQUFBLEdBQUE7QUFDWCxXQUFPLGVBQUEsR0FBa0IsSUFBQyxDQUFBLFdBQTFCLENBRFc7RUFBQSxDQWhDZixDQUFBOztBQUFBLHlCQW1DQSxNQUFBLEdBQVEsU0FBQSxHQUFBLENBbkNSLENBQUE7O0FBQUEseUJBcUNBLFFBQUEsR0FBVSxTQUFBLEdBQUEsQ0FyQ1YsQ0FBQTs7c0JBQUE7O0lBSEosQ0FBQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJCdWlsZGluZ0NvbnRyb2xsZXIgPSByZXF1aXJlKFwiLi9CdWlsZGluZ0NvbnRyb2xsZXJcIikuQnVpbGRpbmdDb250cm9sbGVyXG5cbmNsYXNzIGV4cG9ydHMuQnVpbGRpbmcgZXh0ZW5kcyBQaGFzZXIuU3ByaXRlXG5cbiAgICBjb25zdHJ1Y3RvcjogKEBnYW1lKS0+XG5cbiAgICAgICAgIyBTZXQgb3VyIHBvc2l0aW9uIHRvIHRoZSB3b3JsZCBjZW50ZXJcbiAgICAgICAgeCA9IEBnYW1lLndvcmxkLmNlbnRlclhcbiAgICAgICAgeSA9IEBnYW1lLndvcmxkLmNlbnRlcllcblxuICAgICAgICAjIENhbGwgdGhlIHNwcml0ZSBjb25zdHJ1Y3RvclxuICAgICAgICBzdXBlciBAZ2FtZSwgeCwgeSwgJ3BsYXllcidcblxuICAgICAgICAjIFNldCB0aGUgYW5jaG9yIHRvIHRoZSBjZW50ZXIgb2YgdGhlIHNwcml0ZVxuICAgICAgICBAYW5jaG9yLnNldFRvIDAuNSwgMC41XG5cbiAgICAgICAgIyAjIEVuYWJsZSBwaHlzaWNzXG4gICAgICAgICMgQGdhbWUucGh5c2ljcy5lbmFibGUgQCwgUGhhc2VyLlBoeXNpY3MuQVJDQURFXG5cbiAgICAgICAgIyBBdHRhY2ggYSBjb250cm9sbGVyXG4gICAgICAgIEBjb250cm9sbGVyID0gbmV3IEJ1aWxkaW5nQ29udHJvbGxlciBAZ2FtZSwgQFxuXG4gICAgICAgIHJldHVybiB0aGlzXG5cblxuICAgIHVwZGF0ZTogKCk9PlxuXG4gICAgICAgICMgVXBkYXRlIHRoZSBwbGF5ZXIgY29udHJvbGxlclxuICAgICAgICBAY29udHJvbGxlci51cGRhdGUoKVxuIiwiY2xhc3MgZXhwb3J0cy5CdWlsZGluZ0NvbnRyb2xsZXJcblxuICAgIGNvbnN0cnVjdG9yOiAoQGdhbWUsIEBidWlsZGluZyktPlxuXG4gICAgICAgIEBidWlsZGluZy5pbnB1dEVuYWJsZWQgPSB0cnVlXG4gICAgICAgIEBidWlsZGluZy5pbnB1dC5lbmFibGVEcmFnKClcbiAgICAgICAgQGJ1aWxkaW5nLmlucHV0LmVuYWJsZVNuYXAgMzIsIDMyLCB0cnVlLCB0cnVlXG4gICAgICAgICMgQGJ1aWxkaW5nLmlucHV0LnN0YXJ0RHJhZyhAZ2FtZS5pbnB1dC5tb3VzZVBvaW50ZXIpXG5cbiAgICB1cGRhdGU6ICgpLT5cblxuICAgICMgICAgICMgTW92ZSB0aGUgYnVpbGRpbmcgdG8gdGhlIG1vdXNlIHBvaW50ZXJcbiAgICAjICAgICBAYnVpbGRpbmcueCA9IEBnYW1lLmlucHV0Lm1vdXNlLlxuIiwiY2xhc3MgZXhwb3J0cy5FbmVteSBleHRlbmRzIFBoYXNlci5TcHJpdGVcbiAgICAjIGhvdyBmYXN0IGNhbiB3ZSBtb3ZlXG4gICAgTUFYX1NQRUVEOiAxMDBcbiAgICBNSU5fRElTVEFOQ0U6IDY0XG5cbiAgICBjb25zdHJ1Y3RvcjogKEBnYW1lLCBAcGxheWVyKS0+XG5cbiAgICAgICAgIyBTZXQgb3VyIHBvc2l0aW9uIHRvIHRoZSB3b3JsZCBjZW50ZXJcbiAgICAgICAgeCA9IEBnYW1lLndvcmxkLmNlbnRlclhcbiAgICAgICAgeSA9IEBnYW1lLndvcmxkLmNlbnRlcllcblxuICAgICAgICAjIENhbGwgdGhlIHNwcml0ZSBjb25zdHJ1Y3RvclxuICAgICAgICBzdXBlciBAZ2FtZSwgeCwgeSwgJ2VuZW15J1xuXG4gICAgICAgICMgU2V0IHRoZSBhbmNob3IgdG8gdGhlIGNlbnRlciBvZiB0aGUgc3ByaXRlXG4gICAgICAgIEBhbmNob3Iuc2V0VG8gMC41LCAwLjVcblxuICAgICAgICAjIEFkZCBzb21lIGFuaW1hdGlvbnNcbiAgICAgICAgQGFuaW1hdGlvbnMuYWRkICd1cCcsIFswLCAxLCAyLCAzXSwgMTAsIHRydWVcbiAgICAgICAgQGFuaW1hdGlvbnMuYWRkICdkb3duJywgWzQsIDUsIDYsIDddLCAxMCwgdHJ1ZVxuICAgICAgICBAYW5pbWF0aW9ucy5hZGQgJ2xlZnQnLCBbOCwgOSwgMTAsIDExXSwgMTAsIHRydWVcbiAgICAgICAgQGFuaW1hdGlvbnMuYWRkICdyaWdodCcsIFsxMiwgMTMsIDE0LCAxNV0sIDEwLCB0cnVlXG5cbiAgICAgICAgIyBFbmFibGUgcGh5c2ljc1xuICAgICAgICBAZ2FtZS5waHlzaWNzLmVuYWJsZSBALCBQaGFzZXIuUGh5c2ljcy5BUkNBREVcblxuICAgICAgICAjIGFkZCBvdXJzZWx2ZXMgdG8gdGhlIGdhbWUgc3RhdGVcbiAgICAgICAgZ2FtZS5hZGQuZXhpc3RpbmcgdGhpc1xuXG4gICAgICAgIEBhbmltYXRpb25zLnBsYXkoJ2Rvd24nKVxuXG4gICAgICAgIHJldHVybiB0aGlzXG5cblxuICAgIHVwZGF0ZTogKCk9PlxuICAgICAgICBAZm9sbG93KEBwbGF5ZXIpXG4gICAgICAgIEB1cGRhdGVGYWNpbmcoKVxuXG4gICAgdXBkYXRlRmFjaW5nOiAoKS0+XG4gICAgICAgIGggPSBpZiBAYm9keS52ZWxvY2l0eS54IDwgMCB0aGVuICdsZWZ0JyBlbHNlICdyaWdodCdcbiAgICAgICAgdiA9IGlmIEBib2R5LnZlbG9jaXR5LnkgPCAwIHRoZW4gJ3VwJyBlbHNlICdkb3duJ1xuICAgICAgICBkaXIgPSBpZiBNYXRoLmFicyhAYm9keS52ZWxvY2l0eS54KSA+IE1hdGguYWJzKEBib2R5LnZlbG9jaXR5LnkpIHRoZW4gaCBlbHNlIHZcbiAgICAgICAgQGFuaW1hdGlvbnMucGxheShkaXIpXG5cbiAgICBuZXdEaXJlY3Rpb246ICgpLT5cbiAgICAgICAgZGlyZWN0aW9uID0gQGdhbWUucmFuZC5waWNrIFsndXAnLCAnZG93bicsICdsZWZ0JywgJ3JpZ2h0J11cbiAgICAgICAgY29uc29sZS5sb2cgZGlyZWN0aW9uXG4gICAgICAgIHJldHVybiBkaXJlY3Rpb25cblxuICAgIGZvbGxvdzogKHRhcmdldCktPlxuICAgICAgICAjIENhbGN1bGF0ZSBkaXN0YW5jZSB0byB0YXJnZXRcbiAgICAgICAgZGlzdGFuY2UgPSBAZ2FtZS5tYXRoLmRpc3RhbmNlKEB4LCBAeSwgdGFyZ2V0LngsIHRhcmdldC55KVxuXG4gICAgICAgICMgSWYgdGhlIGRpc3RhbmNlID4gTUlOX0RJU1RBTkNFIHRoZW4gbW92ZVxuICAgICAgICBpZiAoZGlzdGFuY2UgPiBATUlOX0RJU1RBTkNFKVxuICAgICAgICAgICAgIyBDYWxjdWxhdGUgdGhlIGFuZ2xlIHRvIHRoZSB0YXJnZXRcbiAgICAgICAgICAgIGFuZ2xlVG9UYXJnZXQgPSBAZ2FtZS5tYXRoLmFuZ2xlQmV0d2VlbihAeCwgQHksIHRhcmdldC54LCB0YXJnZXQueSlcblxuICAgICAgICAgICAgIyBDYWxjdWxhdGUgdmVsb2NpdHkgdmVjdG9yIGJhc2VkIG9uIGFuZ2xlVG9UYXJnZXQgYW5kIEBNQVhfU1BFRURcbiAgICAgICAgICAgIEBib2R5LnZlbG9jaXR5LnggPSBNYXRoLmNvcyhhbmdsZVRvVGFyZ2V0KSAqIEBNQVhfU1BFRURcbiAgICAgICAgICAgIEBib2R5LnZlbG9jaXR5LnkgPSBNYXRoLnNpbihhbmdsZVRvVGFyZ2V0KSAqIEBNQVhfU1BFRURcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgQGJvZHkudmVsb2NpdHkuc2V0VG8oMCwgMClcbiIsImNsYXNzIGV4cG9ydHMuSnVpY2VcblxuICAgIGNvbnN0cnVjdG9yOiAoQGdhbWUpLT5cblxuICAgICAgICBAZGVmYXVsdFNvdW5kVm9sdW1lID0gMVxuXG4gICAgICAgICMgQWRkIHNvdW5kc1xuICAgICAgICBAc25kVGlsZSA9IGdhbWUuYWRkLnNvdW5kKCdzbmRUaWxlJywgQGRlZmF1bHRTb3VuZFZvbHVtZSlcbiAgICAgICAgQHNuZFRpbGUuYWxsb3dNdWx0aXBsZSA9IHRydWVcblxuICAgICAgICBAc25kTWlzc2lsZSA9IGdhbWUuYWRkLnNvdW5kKCdzbmRNaXNzaWxlJywgQGRlZmF1bHRTb3VuZFZvbHVtZSlcbiAgICAgICAgQHNuZFRpbGUuYWxsb3dNdWx0aXBsZSA9IHRydWVcblxuXG4gICAgICAgICMgcGFydGljbGVzXG4gICAgICAgIEBlbWl0dGVyID0gZ2FtZS5hZGQuZW1pdHRlcigwLCAwLCAxMDAwKVxuXG4gICAgICAgIEBlbWl0dGVyLm1ha2VQYXJ0aWNsZXMoJ3BhcnRpY2xlJylcbiAgICAgICAgQGVtaXR0ZXIuZ3Jhdml0eSA9IDMwMFxuXG5cbiAgICAgICAgcmV0dXJuIHRoaXNcblxuXG4gICAgc2hha2U6ICgpLT5cbiAgICAgICAgQGdhbWUuYWRkLnR3ZWVuKEBnYW1lLmNhbWVyYSlcbiAgICAgICAgICAgIC5mcm9tKHsgeTogQGdhbWUuY2FtZXJhLnkgLSA1IH0sIDUwLCBQaGFzZXIuRWFzaW5nLlNpbnVzb2lkYWwuSW5PdXQsIGZhbHNlLCAwLCA0LCB0cnVlKVxuICAgICAgICAgICAgLnN0YXJ0KClcbiAgICAgICAgIyBjb25zb2xlLmxvZyAnc2hha2UhJ1xuXG4gICAgc3Bsb2RlOiAoeCwgeSktPlxuICAgICAgICAjICBQb3NpdGlvbiB0aGUgZW1pdHRlciB3aGVyZSB0aGUgbW91c2UvdG91Y2ggZXZlbnQgd2FzXG4gICAgICAgIEBlbWl0dGVyLnggPSB4XG4gICAgICAgIEBlbWl0dGVyLnkgPSB5XG5cbiAgICAgICAgIyAgVGhlIGZpcnN0IHBhcmFtZXRlciBzZXRzIHRoZSBlZmZlY3QgdG8gXCJleHBsb2RlXCIgd2hpY2ggbWVhbnMgYWxsIHBhcnRpY2xlcyBhcmUgZW1pdHRlZCBhdCBvbmNlXG4gICAgICAgICMgIFRoZSBzZWNvbmQgZ2l2ZXMgZWFjaCBwYXJ0aWNsZSBhIDIwMDBtcyBsaWZlc3BhblxuICAgICAgICAjICBUaGUgdGhpcmQgaXMgaWdub3JlZCB3aGVuIHVzaW5nIGJ1cnN0L2V4cGxvZGUgbW9kZVxuICAgICAgICAjICBUaGUgZmluYWwgcGFyYW1ldGVyICgxMCkgaXMgaG93IG1hbnkgcGFydGljbGVzIHdpbGwgYmUgZW1pdHRlZCBpbiB0aGlzIHNpbmdsZSBidXJzdFxuICAgICAgICBAZW1pdHRlci5zdGFydCh0cnVlLCAyNTAsIG51bGwsIDUpXG5cbiAgICBwZXc6ICgpIC0+XG4gICAgICAgIEBzbmRNaXNzaWxlLnBsYXkoKVxuXG4gICAgcGxvcDogKHgsIHkpLT5cbiAgICAgICAgIyBwbGF5IGEgbmV3IHBsb3Agc291bmRcbiAgICAgICAgIyBzbmRUaWxlID0gZ2FtZS5hZGQuc291bmQoJ3NuZFRpbGUnLCBAZGVmYXVsdFNvdW5kVm9sdW1lKVxuICAgICAgICBAc25kVGlsZS5wbGF5KClcblxuICAgICAgICBAc3Bsb2RlIHgsIHlcbiIsIkp1aWNlID0gcmVxdWlyZShcIi4vSnVpY2VcIikuSnVpY2VcblxuUGxheWVyID0gcmVxdWlyZShcIi4vUGxheWVyXCIpLlBsYXllclxuQnVpbGRpbmcgPSByZXF1aXJlKFwiLi9CdWlsZGluZ1wiKS5CdWlsZGluZ1xuXG5FbmVteSA9IHJlcXVpcmUoXCIuL0VuZW15XCIpLkVuZW15XG5cblRvb2xNaXNzaWxlID0gcmVxdWlyZShcIi4vVG9vbE1pc3NpbGVcIikuVG9vbE1pc3NpbGVcblxud2luZG93Lm9ubG9hZCA9ICgpLT5cblxuICAgICMgT24gd2luZG93IGxvYWQsIGNyZWF0ZSB0aGUgUGhhc2VyIGdhbWUgb2JqZWN0LFxuICAgICMgIGFuZCBsb2FkIGdhbWVzdGF0ZSBhcyB0aGUgaW5pdGlhbCBzdGF0ZVxuICAgIHdpbmRvdy5nYW1lID0gbmV3IFBoYXNlci5HYW1lKDY0MCwgNjQwLCBQaGFzZXIuQ0FOVkFTLCAnZ2FtZS1jb250YWluZXInLCBnYW1lc3RhdGUpXG5cbmdhbWVzdGF0ZSA9XG4gICAgcHJlbG9hZDogKCktPlxuICAgICAgICAjIExvYWQgdXMgc29tZSBhc3NldHNcbiAgICAgICAgIyBnYW1lLmxvYWQuaW1hZ2UgJ3BsYXllcicsICdhc3NldHMvaW1nL3BsYXllci5wbmcnXG4gICAgICAgIGdhbWUubG9hZC5pbWFnZSAndGlsZVNlbGVjdCcsICdhc3NldHMvaW1nL3N0YXIxLnBuZydcbiAgICAgICAgZ2FtZS5sb2FkLmltYWdlICdzdGFyMicsICdhc3NldHMvaW1nL3N0YXIyLnBuZydcbiAgICAgICAgZ2FtZS5sb2FkLmltYWdlICdtaXNzaWxlJywgJ2Fzc2V0cy9pbWcvc3RhcjMucG5nJ1xuICAgICAgICBnYW1lLmxvYWQuaW1hZ2UgJ3BhcnRpY2xlJywgJ2Fzc2V0cy9pbWcvZmxhc2gucG5nJ1xuXG4gICAgICAgICMgbG9hZCB0aGUgcGxheWVyIHNwcml0ZXNoZWV0XG4gICAgICAgIGdhbWUubG9hZC5zcHJpdGVzaGVldCAncGxheWVyJywgJ2Fzc2V0cy9pbWcvcGxheWVyLnBuZycsIDMyLCAzMlxuXG4gICAgICAgICMgbG9hZCBhbiBlbmVteSBzcHJpdGVzaGVldFxuICAgICAgICBnYW1lLmxvYWQuc3ByaXRlc2hlZXQgJ2VuZW15JywgJ2Fzc2V0cy9pbWcvZW5lbXkucG5nJywgNjQsIDY0XG5cbiAgICAgICAgIyBMb2FkIHRpbGVzXG4gICAgICAgIGdhbWUubG9hZC5pbWFnZSAndGlsZXMnLCAnYXNzZXRzL2ltZy90aWxlcy5wbmcnXG5cbiAgICAgICAgIyBsb2FkIHNvbWUgc291bmRzXG4gICAgICAgIGdhbWUubG9hZC5hdWRpbygnc25kTWlzc2lsZScsICdhc3NldHMvc25kL3N0ZWFtLm9nZycpXG4gICAgICAgICMgZ2FtZS5sb2FkLmF1ZGlvKCdzbmRUaWxlJywgJ2Fzc2V0cy9zbmQvcm9sbG92ZXIxLndhdicpXG4gICAgICAgICMgZ2FtZS5sb2FkLmF1ZGlvKCdzbmRUaWxlJywgJ2Fzc2V0cy9zbmQvcm9sbG92ZXIyLndhdicpXG4gICAgICAgICMgZ2FtZS5sb2FkLmF1ZGlvKCdzbmRUaWxlJywgJ2Fzc2V0cy9zbmQvcm9sbG92ZXIzLndhdicpXG4gICAgICAgICMgZ2FtZS5sb2FkLmF1ZGlvKCdzbmRUaWxlJywgJ2Fzc2V0cy9zbmQvcm9sbG92ZXI0LndhdicpXG4gICAgICAgICMgZ2FtZS5sb2FkLmF1ZGlvKCdzbmRUaWxlJywgJ2Fzc2V0cy9zbmQvcm9sbG92ZXI1LndhdicpXG4gICAgICAgIGdhbWUubG9hZC5hdWRpbygnc25kVGlsZScsICdhc3NldHMvc25kL3JvbGxvdmVyNi53YXYnKVxuXG5cbiAgICBjcmVhdGU6ICgpLT5cbiAgICAgICAgIyAjIEFkZCBhIEhlbGxvIFdvcmxkIG1lc3NhZ2VcbiAgICAgICAgIyBmb28gPSBnYW1lLmFkZC50ZXh0IDEwLCAxMCwgXCJIZWxsbyBXb3JsZFwiLCB7ZmlsbDogJ3doaXRlJ31cblxuICAgICAgICAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcblxuICAgICAgICAjIENyZWF0ZSBhIHBvb2wgb2YgYXN0ZXJvaWRzXG4gICAgICAgIE1BWF9BU1RFUk9JRFMgPSAxMDBcbiAgICAgICAgQGFzdGVyb2lkR3JvdXAgPSBAZ2FtZS5hZGQuZ3JvdXAoKVxuICAgICAgICBAYXN0ZXJvaWRHcm91cC5lbmFibGVCb2R5ID0gdHJ1ZVxuICAgICAgICBAYXN0ZXJvaWRHcm91cC5waHlzaWNzQm9keVR5cGUgPSBQaGFzZXIuUGh5c2ljcy5BUkNBREVcbiAgICAgICAgIyBAZ2FtZS5waHlzaWNzLmVuYWJsZShAYXN0ZXJvaWRHcm91cCwgUGhhc2VyLlBoeXNpY3MuQVJDQURFKVxuICAgICAgICBAYXN0ZXJvaWRHcm91cC5jcmVhdGVNdWx0aXBsZShNQVhfQVNURVJPSURTLCAncGFydGljbGUnLCAwKVxuXG4gICAgICAgICMgQ3JlYXRlIGEgdGltZXIgZm9yIHNwYXduaW5nIGEgbmV3IGFzdGVyb2lkXG4gICAgICAgIEBhc3Rlcm9pZFRpbWVyID0gMFxuXG4gICAgICAgICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xuICAgICAgICAjICBDcmVhdGVzIGEgYmxhbmsgdGlsZW1hcFxuICAgICAgICBAbWFwID0gZ2FtZS5hZGQudGlsZW1hcCgpXG5cbiAgICAgICAgIyAgQWRkIGEgVGlsZXNldCBpbWFnZSB0byB0aGUgbWFwXG4gICAgICAgIEBtYXAuYWRkVGlsZXNldEltYWdlKCd0aWxlcycpXG5cbiAgICAgICAgIyBpbmNyZWFzZSB0aGUgdGlsZW1hcCBiaWFzIGluIHRoZSBwaHlzaWNzIHN5c3RlbSB0byBwcmV2ZW50IGNsaXBwaW5nIGludG8gdGlsZXNcbiAgICAgICAgIyBnYW1lLnBoeXNpY3MuYXJjYWRlLlRJTEVfQklBUyA9IDY0XG5cbiAgICAgICAgTUFQX1dJRFRIID0gNDBcbiAgICAgICAgTUFQX0hFSUdIVCA9IDMwXG5cbiAgICAgICAgIyAgQ3JlYXRlcyBhIG5ldyBibGFuayBsYXllciBhbmQgc2V0cyB0aGUgbWFwIGRpbWVuc2lvbnMuXG4gICAgICAgICMgIEluIHRoaXMgY2FzZSB0aGUgbWFwIGlzIDQweDMwIHRpbGVzIGluIHNpemUgYW5kIHRoZSB0aWxlcyBhcmUgMzJ4MzIgcGl4ZWxzIGluIHNpemUuXG4gICAgICAgIGxheWVyMSA9IEBtYXAuY3JlYXRlKCdsZXZlbDEnLCBNQVBfV0lEVEgsIE1BUF9IRUlHSFQsIDMyLCAzMilcbiAgICAgICAgIyBsYXllcjEuc2Nyb2xsRmFjdG9yWCA9IDAuNVxuICAgICAgICAjIGxheWVyMS5zY3JvbGxGYWN0b3JZID0gMC41XG5cbiAgICAgICAgIyAgUmVzaXplIHRoZSB3b3JsZFxuICAgICAgICBsYXllcjEucmVzaXplV29ybGQoKVxuXG4gICAgICAgICMgbGF5ZXIxLmRlYnVnID0gdHJ1ZVxuXG4gICAgICAgIEBjdXJyZW50TGF5ZXIgPSBsYXllcjFcbiAgICAgICAgQGN1cnJlbnRUaWxlID0gN1xuXG4gICAgICAgICMgQG1hcC5wdXRUaWxlKEBjdXJyZW50VGlsZSwgMCwgMCwgQGN1cnJlbnRMYXllcilcbiAgICAgICAgQG1hcC5maWxsKEBjdXJyZW50VGlsZSwgMCwgMCwgTUFQX1dJRFRILCBNQVBfSEVJR0hULCBAY3VycmVudExheWVyKVxuXG4gICAgICAgICMgbWFrZSBhIGxpdHRsZSBpc2xhbmRcbiAgICAgICAgQGN1cnJlbnRUaWxlID0gMFxuICAgICAgICBAbWFwLmZpbGwoQGN1cnJlbnRUaWxlLCAxMCwgMTAsIDE4LCAxMCwgQGN1cnJlbnRMYXllcilcblxuXG4gICAgICAgIEBnYW1lLmN1cnJlbnRMZXZlbCA9IHtcbiAgICAgICAgICAgIHRpbGVtYXA6IEBtYXAsXG4gICAgICAgICAgICBjdXJyZW50TGF5ZXI6IEBjdXJyZW50TGF5ZXIsXG4gICAgICAgIH1cblxuICAgICAgICAjIHNldCBjb2xsaXNpb24gb24gdGhlIHRpbGVtYXBcbiAgICAgICAgIyB0aGlzIGlzIGRvbmUgYWZ0ZXIgZ2VuZXJhdGluZyB0aGUgbWFwIHNvIHRoYXQgY29sbGlzaW9uIHdpbGwgdXBkYXRlIHByb3Blcmx5XG4gICAgICAgICMgdGhlIGZpbGwgY29tbWFuZCBkb2Vzbid0IHNlZW0gdG8gdXBhdGUgdGhlIGNvbGxpc2lvbiBib3hlc1xuICAgICAgICBAbWFwLnNldENvbGxpc2lvbihbIDcgXSwgdHJ1ZSwgJ2xldmVsMScpXG5cbiAgICAgICAgIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXG5cblxuICAgICAgICAjIENyZWF0ZSBhIHBsYXllciBvYmplY3RcbiAgICAgICAgQHBsYXllciA9IG5ldyBQbGF5ZXIoZ2FtZSlcblxuICAgICAgICAjIENyZWF0ZSBhbiBlbmVteSBvYmplY3RcbiAgICAgICAgQGVuZW15ID0gbmV3IEVuZW15KGdhbWUsIEBwbGF5ZXIpXG5cblxuICAgICAgICAjIEhhdmUgdGhlIGNhbWVyYSBmb2xsb3cgdGhlIHBsYXllclxuICAgICAgICBAZ2FtZS5jYW1lcmEuZm9sbG93IEBwbGF5ZXIsIFBoYXNlci5DYW1lcmEuRk9MTE9XX1RPUERPV05fVElHSFRcblxuICAgICAgICAjICMgQ3JlYXRlIGEgYnVpbGRpbmcgb2JqZWN0XG4gICAgICAgICMgYnVpbGRpbmcgPSBuZXcgQnVpbGRpbmcoZ2FtZSlcbiAgICAgICAgIyAjIEFkZCB0aGUgYnVpbGRpbmcgb2JqZWN0XG4gICAgICAgICMgZ2FtZS5hZGQuZXhpc3RpbmcgYnVpbGRpbmdcblxuICAgICAgICAjIGFkZCB1cyBhIGp1aWNlXG4gICAgICAgIEBnYW1lLmp1aWNlID0gbmV3IEp1aWNlKEBnYW1lKVxuXG4gICAgICAgICMgU2hvdyBGUFNcbiAgICAgICAgQGdhbWUudGltZS5hZHZhbmNlZFRpbWluZyA9IHRydWU7XG4gICAgICAgIEBzdGF0dXNUZXh0ID0gQGdhbWUuYWRkLnRleHQoXG4gICAgICAgICAgICAyMCwgMjAsICcnLCB7IGZvbnQ6ICcxNnB4IEFyaWFsJywgZmlsbDogJyNmZmZmZmYnIH1cbiAgICAgICAgKTtcbiAgICAgICAgQHN0YXR1c1RleHQuZml4ZWRUb0NhbWVyYSA9IHRydWVcblxuXG5cbiAgICB1cGRhdGU6ICgpLT5cbiAgICAgICAgQGdhbWUucGh5c2ljcy5hcmNhZGUuY29sbGlkZShAcGxheWVyLCBAY3VycmVudExheWVyKVxuXG4gICAgICAgICMgZGVidWcgZnBzXG4gICAgICAgIEBzdGF0dXNUZXh0LnNldFRleHQoQGdldFN0YXR1c1RleHQoKSlcblxuICAgICAgICAjIFNwYXduIGEgbmV3IGFzdGVyb2lkXG4gICAgICAgIEBhc3Rlcm9pZFRpbWVyIC09IEBnYW1lLnRpbWUuZWxhcHNlZFxuICAgICAgICBpZiAoQGFzdGVyb2lkVGltZXIgPD0gMClcbiAgICAgICAgICAgIEBhc3Rlcm9pZFRpbWVyID0gQGdhbWUucm5kLmludGVnZXJJblJhbmdlKDUsIDUwKVxuICAgICAgICAgICAgQGNyZWF0ZU5ld0FzdGVyb2lkKClcblxuICAgICAgICAjIG1hcmtlclggPSBAY3VycmVudExheWVyLmdldFRpbGVYKGdhbWUuaW5wdXQuYWN0aXZlUG9pbnRlci53b3JsZFgpICogMzJcbiAgICAgICAgIyBtYXJrZXJZID0gQGN1cnJlbnRMYXllci5nZXRUaWxlWShnYW1lLmlucHV0LmFjdGl2ZVBvaW50ZXIud29ybGRZKSAqIDMyXG4gICAgICAgICNcbiAgICAgICAgIyBpZiAoQGdhbWUuaW5wdXQubW91c2VQb2ludGVyLmlzRG93bilcbiAgICAgICAgIyAgICAgQHBsYXllci5hbmltYXRpb25zLnBsYXkoJ2Nhc3QnKVxuICAgICAgICAjICAgICAjIEBtYXAucHV0VGlsZShAY3VycmVudFRpbGUsIEBjdXJyZW50TGF5ZXIuZ2V0VGlsZVgobWFya2VyWCksIEBjdXJyZW50TGF5ZXIuZ2V0VGlsZVkobWFya2VyWSksIEBjdXJyZW50TGF5ZXIpXG4gICAgICAgICMgICAgIGlmIChnYW1lLmlucHV0LmtleWJvYXJkLmlzRG93bihQaGFzZXIuS2V5Ym9hcmQuU0hJRlQpKVxuICAgICAgICAjICAgICAgICAgQGN1cnJlbnRUaWxlID0gQG1hcC5nZXRUaWxlKEBjdXJyZW50TGF5ZXIuZ2V0VGlsZVgobWFya2VyWCksIEBjdXJyZW50TGF5ZXIuZ2V0VGlsZVkobWFya2VyWSkpLmluZGV4XG4gICAgICAgICMgICAgIGVsc2VcbiAgICAgICAgIyAgICAgICAgIGlmIChAbWFwLmdldFRpbGUoQGN1cnJlbnRMYXllci5nZXRUaWxlWChtYXJrZXJYKSwgQGN1cnJlbnRMYXllci5nZXRUaWxlWShtYXJrZXJZKSkuaW5kZXggIT0gQGN1cnJlbnRUaWxlKVxuICAgICAgICAjICAgICAgICAgICAgIEBtYXAucHV0VGlsZShAY3VycmVudFRpbGUsIEBjdXJyZW50TGF5ZXIuZ2V0VGlsZVgobWFya2VyWCksIEBjdXJyZW50TGF5ZXIuZ2V0VGlsZVkobWFya2VyWSkpXG4gICAgICAgICMgICAgICAgICAgICAgQGdhbWUuanVpY2UucGxvcChnYW1lLmlucHV0LmFjdGl2ZVBvaW50ZXIud29ybGRYLCBnYW1lLmlucHV0LmFjdGl2ZVBvaW50ZXIud29ybGRZKVxuICAgICAgICAjIGVsc2VcbiAgICAgICAgIyAgICAgQHBsYXllci5hbmltYXRpb25zLnBsYXkoJ2lkbGUnKVxuICAgICAgICAjXG4gICAgICAgICMgaWYgQGdhbWUuaW5wdXQua2V5Ym9hcmQuZG93bkR1cmF0aW9uKFBoYXNlci5LZXlib2FyZC5RLCAxMClcbiAgICAgICAgIyAgICAgQGN1cnJlbnRUaWxlID0gUGhhc2VyLk1hdGguY2xhbXAgQGN1cnJlbnRUaWxlIC0gMSwgMCwgN1xuICAgICAgICAjICAgICBjb25zb2xlLmxvZyAnY3VycmVudFRpbGUgLS0gdG8gJyArIEBjdXJyZW50VGlsZVxuICAgICAgICAjIGlmIEBnYW1lLmlucHV0LmtleWJvYXJkLmRvd25EdXJhdGlvbihQaGFzZXIuS2V5Ym9hcmQuRSwgMTApXG4gICAgICAgICMgICAgIEBjdXJyZW50VGlsZSA9IFBoYXNlci5NYXRoLmNsYW1wIEBjdXJyZW50VGlsZSArIDEsIDAsIDdcbiAgICAgICAgIyAgICAgY29uc29sZS5sb2cgJ2N1cnJlbnRUaWxlICsrIHRvICcgKyBAY3VycmVudFRpbGVcblxuICAgIGNyZWF0ZU5ld0FzdGVyb2lkOiAoKSAtPlxuICAgICAgICBhc3Rlcm9pZCA9IEBhc3Rlcm9pZEdyb3VwLmdldEZpcnN0RGVhZCgpICMgUmVjeWNsZSBhIGRlYWQgYXN0ZXJvaWRcblxuICAgICAgICBpZiAoYXN0ZXJvaWQpXG4gICAgICAgICAgICBkeCA9IDBcbiAgICAgICAgICAgIGR5ID0gMFxuICAgICAgICAgICAgc2xvdyA9IDEwXG4gICAgICAgICAgICBmYXN0ID0gNTBcbiAgICAgICAgICAgIHdoaWxlIChkeCA8IHNsb3cgJiYgZHggPiAtc2xvdyAmJiBkeSA8IHNsb3cgJiYgZHkgPiAtc2xvdylcbiAgICAgICAgICAgICAgICBkeCA9IEBnYW1lLnJuZC5iZXR3ZWVuKC1mYXN0LCBmYXN0KVxuICAgICAgICAgICAgICAgIGR5ID0gQGdhbWUucm5kLmJldHdlZW4oLWZhc3QsIGZhc3QpXG5cbiAgICAgICAgICAgIHN4ID0gaWYgZHggPiAwIHRoZW4gMCBlbHNlIEBnYW1lLndvcmxkLndpZHRoXG4gICAgICAgICAgICBzeSA9IGlmIGR5ID4gMCB0aGVuIDAgZWxzZSBAZ2FtZS53b3JsZC5oZWlnaHRcblxuICAgICAgICAgICAgZGlyZWN0aW9uID0gQGdhbWUucm5kLnBpY2soWydoJywgJ3YnXSlcbiAgICAgICAgICAgIHN4ID0gaWYgZGlyZWN0aW9uID09ICdoJyB0aGVuIEBnYW1lLnJuZC5iZXR3ZWVuKDAsIEBnYW1lLndvcmxkLndpZHRoKSBlbHNlIHN4XG4gICAgICAgICAgICBzeSA9IGlmIGRpcmVjdGlvbiA9PSAndicgdGhlbiBAZ2FtZS5ybmQuYmV0d2VlbigwLCBAZ2FtZS53b3JsZC5oZWlnaHQpIGVsc2Ugc3lcblxuICAgICAgICAgICAgIyBhc3Rlcm9pZC5yZXNldChAZ2FtZS53b3JsZC53aWR0aCArIDEwMCwgQGdhbWUud29ybGQuaGVpZ2h0IC0gNDgpICMgUG9zaXRpb24gb24gZ3JvdW5kXG4gICAgICAgICAgICBhc3Rlcm9pZC5yZXNldChzeCwgc3kpICMgUG9zaXRpb24gb24gZ3JvdW5kXG4gICAgICAgICAgICBhc3Rlcm9pZC5yZXZpdmUoKSAjIFNldCBcImFsaXZlXCJcblxuICAgICAgICAgICAgIyBzZXQgYSByYW5kb20gc2NhbGUgYW5kIGFscGhhXG4gICAgICAgICAgICBkZXB0aCA9IEBnYW1lLnJuZC5yZWFsSW5SYW5nZSgwLjEsIDAuOClcbiAgICAgICAgICAgICMgYXN0ZXJvaWQuc2NhbGUgPSBkZXB0aFxuICAgICAgICAgICAgYXN0ZXJvaWQuYWxwaGEgPSBkZXB0aFxuXG4gICAgICAgICAgICBhc3Rlcm9pZC5ib2R5LnZlbG9jaXR5LnNldFRvKDAsIDApICMgU3RvcCBtb3ZpbmdcbiAgICAgICAgICAgIGFzdGVyb2lkLmJvZHkuYWNjZWxlcmF0aW9uLnNldFRvKDAsIDApICMgU3RvcCBhY2NlbGVyYXRpbmdcblxuICAgICAgICAgICAgIyBTZXQgaW5pdGlhbCBtb3ZlbWVudFxuICAgICAgICAgICAgYXN0ZXJvaWQuYm9keS52ZWxvY2l0eS54ID0gZHhcbiAgICAgICAgICAgIGFzdGVyb2lkLmJvZHkudmVsb2NpdHkueSA9IGR5XG5cbiAgICAgICAgICAgICMgU2V0IHJhbmRvbSByb3RhdGlvblxuICAgICAgICAgICAgYXN0ZXJvaWQucm90YXRpb24gPSBQaGFzZXIuTWF0aC5kZWdUb1JhZChAZ2FtZS5ybmQuYW5nbGUoKSkgIyBSZXNldCByb3RhdGlvblxuXG4gICAgICAgICAgICAjIFNldCBhbmltYXRpb24gZnJhbWUgdG8gMFxuICAgICAgICAgICAgYXN0ZXJvaWQuZnJhbWUgPSAwXG5cbiAgICAgICAgICAgICMgQ2VudGVyIHNwcml0ZVxuICAgICAgICAgICAgYXN0ZXJvaWQuYW5jaG9yLnNldFRvKDAuNSwgMC41KVxuXG4gICAgICAgICAgICAjIEFzdGVyb2lkcyBzaG91bGQga2lsbCB0aGVtc2VsdmVzIHdoZW4gdGhleSBsZWF2ZSB0aGUgd29ybGQuXG4gICAgICAgICAgICAjIFBoYXNlciB0YWtlcyBjYXJlIG9mIHRoaXMgZm9yIG1lIGJ5IHNldHRpbmcgdGhpcyBmbGFnXG4gICAgICAgICAgICAjIGJ1dCB5b3UgY2FuIGRvIGl0IHlvdXJzZWxmIGJ5IGtpbGxpbmcgdGhlIGFzdGVyb2lkIGlmXG4gICAgICAgICAgICAjIGl0cyB4LHkgY29vcmRpbmF0ZXMgYXJlIG91dHNpZGUgb2YgdGhlIHdvcmxkLlxuICAgICAgICAgICAgYXN0ZXJvaWQuY2hlY2tXb3JsZEJvdW5kcyA9IHRydWVcbiAgICAgICAgICAgIGFzdGVyb2lkLm91dE9mQm91bmRzS2lsbCA9IHRydWVcblxuICAgIGdldFN0YXR1c1RleHQ6ICgpLT5cbiAgICAgICAgc3RhdHVzID0gJydcbiAgICAgICAgc3RhdHVzICs9IEBnYW1lLnRpbWUuZnBzICsgJyBGUFMnICsgJ1xcbidcbiAgICAgICAgc3RhdHVzICs9ICdUT09MOiAnICsgQHBsYXllci50b29sLm5hbWUgKyAnXFxuJ1xuICAgICAgICBzdGF0dXMgKz0gQHBsYXllci50b29sLmdldFN0YXR1c1RleHQoKVxuICAgICAgICByZXR1cm4gc3RhdHVzXG4iLCJQbGF5ZXJDb250cm9sbGVyID0gcmVxdWlyZShcIi4vUGxheWVyQ29udHJvbGxlclwiKS5QbGF5ZXJDb250cm9sbGVyXG5cblRvb2xNaXNzaWxlID0gcmVxdWlyZShcIi4vVG9vbE1pc3NpbGVcIikuVG9vbE1pc3NpbGVcblRvb2xCdWlsZCA9IHJlcXVpcmUoXCIuL1Rvb2xCdWlsZFwiKS5Ub29sQnVpbGRcblRvb2xUZWxlcG9ydCA9IHJlcXVpcmUoXCIuL1Rvb2xUZWxlcG9ydFwiKS5Ub29sVGVsZXBvcnRcblxuXG5jbGFzcyBleHBvcnRzLlBsYXllciBleHRlbmRzIFBoYXNlci5TcHJpdGVcbiAgICAjIGhvdyBmYXN0IGNhbiB3ZSBtb3ZlXG4gICAgc3BlZWQ6IDI1MFxuXG4gICAgY29uc3RydWN0b3I6IChAZ2FtZSktPlxuXG4gICAgICAgICMgU2V0IG91ciBwb3NpdGlvbiB0byB0aGUgd29ybGQgY2VudGVyXG4gICAgICAgIHggPSBAZ2FtZS53b3JsZC5jZW50ZXJYXG4gICAgICAgIHkgPSBAZ2FtZS53b3JsZC5jZW50ZXJZXG5cbiAgICAgICAgIyBDYWxsIHRoZSBzcHJpdGUgY29uc3RydWN0b3JcbiAgICAgICAgc3VwZXIgQGdhbWUsIHgsIHksICdwbGF5ZXInXG5cbiAgICAgICAgIyBTZXQgdGhlIGFuY2hvciB0byB0aGUgY2VudGVyIG9mIHRoZSBzcHJpdGVcbiAgICAgICAgQGFuY2hvci5zZXRUbyAwLjUsIDAuNVxuXG4gICAgICAgICMgQWRkIHNvbWUgYW5pbWF0aW9uc1xuICAgICAgICBAYW5pbWF0aW9ucy5hZGQgJ2lkbGUnLCBbMF1cbiAgICAgICAgQGFuaW1hdGlvbnMuYWRkICdjYXN0JywgWzFdXG5cbiAgICAgICAgIyBFbmFibGUgcGh5c2ljc1xuICAgICAgICBAZ2FtZS5waHlzaWNzLmVuYWJsZSBALCBQaGFzZXIuUGh5c2ljcy5BUkNBREVcblxuICAgICAgICAjIEF0dGFjaCBhIGNvbnRyb2xsZXJcbiAgICAgICAgQGNvbnRyb2xsZXIgPSBuZXcgUGxheWVyQ29udHJvbGxlciBAZ2FtZSwgQFxuXG4gICAgICAgICMgYWRkIG91cnNlbHZlcyB0byB0aGUgZ2FtZSBzdGF0ZVxuICAgICAgICBnYW1lLmFkZC5leGlzdGluZyB0aGlzXG5cbiAgICAgICAgIyAjIGNyZWF0ZSB0aGUgTWFnaWMgTWlzc2lsZSBUb29sXG4gICAgICAgICMgQHRvb2wgPSBuZXcgVG9vbE1pc3NpbGUgQGdhbWUsIHRoaXNcblxuICAgICAgICAjIGNyZWF0ZSB0aGUgQnVpbGQgVG9vbFxuICAgICAgICAjIEB0b29sID0gbmV3IFRvb2xCdWlsZCBAZ2FtZSwgdGhpc1xuXG4gICAgICAgIEB0b29scyA9IFtcbiAgICAgICAgICAgIG5ldyBUb29sTWlzc2lsZSBAZ2FtZSwgdGhpc1xuICAgICAgICAgICAgbmV3IFRvb2xUZWxlcG9ydCBAZ2FtZSwgdGhpc1xuICAgICAgICAgICAgbmV3IFRvb2xCdWlsZCBAZ2FtZSwgdGhpc1xuICAgICAgICBdXG4gICAgICAgIEBuZXh0VG9vbCgpXG5cbiAgICAgICAgcmV0dXJuIHRoaXNcblxuXG4gICAgdXBkYXRlOiAoKT0+XG5cbiAgICAgICAgIyBVcGRhdGUgdGhlIHBsYXllciBjb250cm9sbGVyXG4gICAgICAgIEBjb250cm9sbGVyLnVwZGF0ZSgpXG5cbiAgICAgICAgIyBVcGRhdGUgb3VyIFRvb2xcbiAgICAgICAgaWYgQHRvb2w/XG4gICAgICAgICAgICBAdG9vbC51cGRhdGUoKVxuXG5cbiAgICBuZXh0VG9vbDogKCktPlxuICAgICAgICAjIGNvbnNvbGUubG9nICdzd2l0Y2hpbmcgZnJvbSAnICsgaWYgQHRvb2wgdGhlbiBAdG9vbC5uYW1lIGVsc2UgJ25vdGhpbmcnXG5cbiAgICAgICAgIyBoaWRlIHRoZSBvbGQgdG9vbFxuICAgICAgICBpZiBAdG9vbFxuICAgICAgICAgICAgQHRvb2wudW5zZWxlY3QoKVxuXG4gICAgICAgICMgZ2V0IHRoZSBuZXh0IHRvb2wgYW5kIHJlbW92ZSBpdCBmcm9tIHRoZSBsaXN0XG4gICAgICAgIEB0b29sID0gQHRvb2xzLnBvcCgpXG5cbiAgICAgICAgIyBzaG93IHRoZSBuZXcgdG9vbFxuICAgICAgICBpZiBAdG9vbFxuICAgICAgICAgICAgQHRvb2xzLnVuc2hpZnQoQHRvb2wpXG4gICAgICAgICAgICAjIHJlYWRkIHRoZSB0b29sIHRvIHRoZWZyb250IG9mIHRoZSBsaXN0XG4gICAgICAgICAgICBAdG9vbC5zZWxlY3QoKVxuXG4gICAgICAgICMgY29uc29sZS5sb2cgJ3RvICcgKyBAdG9vbC5uYW1lXG4iLCJjbGFzcyBleHBvcnRzLlBsYXllckNvbnRyb2xsZXJcblxuICAgIGtleWJvYXJkX21vZGVzOiB7XG4gICAgICAgIFFXRVJUWToge1xuICAgICAgICAgICAgdXA6IFBoYXNlci5LZXlib2FyZC5XXG4gICAgICAgICAgICBkb3duOiBQaGFzZXIuS2V5Ym9hcmQuU1xuICAgICAgICAgICAgbGVmdDogUGhhc2VyLktleWJvYXJkLkFcbiAgICAgICAgICAgIHJpZ2h0OiBQaGFzZXIuS2V5Ym9hcmQuRFxuICAgICAgICB9XG4gICAgICAgIERWT1JBSzoge1xuICAgICAgICAgICAgdXA6IDE4OCAjIENvbW1hXG4gICAgICAgICAgICBkb3duOiBQaGFzZXIuS2V5Ym9hcmQuT1xuICAgICAgICAgICAgbGVmdDogUGhhc2VyLktleWJvYXJkLkFcbiAgICAgICAgICAgIHJpZ2h0OiBQaGFzZXIuS2V5Ym9hcmQuRVxuICAgICAgICB9XG5cbiAgICB9XG5cbiAgICBjb25zdHJ1Y3RvcjogKEBnYW1lLCBAcGxheWVyKS0+XG4gICAgICAgIEBjdXJzb3JzID0gZ2FtZS5pbnB1dC5rZXlib2FyZC5jcmVhdGVDdXJzb3JLZXlzKClcbiAgICAgICAgQHNldEtleW1hcChcIlFXRVJUWVwiKVxuXG4gICAgc2V0S2V5bWFwOiAobW9kZSk9PlxuICAgICAgICBpZiBAa2V5Ym9hcmRfbW9kZXNbbW9kZV0/XG4gICAgICAgICAgICBAa2V5Ym9hcmRfbW9kZSA9IEBrZXlib2FyZF9tb2Rlc1ttb2RlXVxuXG4gICAgdXBkYXRlOiAoKS0+XG5cbiAgICAgICAgIyBSZXNldCB0aGUgcGxheWVyJ3MgdmVsb2NpdHlcbiAgICAgICAgQHBsYXllci5ib2R5LnZlbG9jaXR5LnggPSAwXG4gICAgICAgIEBwbGF5ZXIuYm9keS52ZWxvY2l0eS55ID0gMFxuXG4gICAgICAgICMgU2V0IGxlZnQgb3IgcmlnaHQgdmVsb2NpdHlcbiAgICAgICAgaWYgQGN1cnNvcnMubGVmdC5pc0Rvd24gb3IgQGdhbWUuaW5wdXQua2V5Ym9hcmQuaXNEb3duKEBrZXlib2FyZF9tb2RlLmxlZnQpXG4gICAgICAgICAgICBAcGxheWVyLmJvZHkudmVsb2NpdHkueCA9IC0xICogQHBsYXllci5zcGVlZFxuICAgICAgICBlbHNlIGlmIEBjdXJzb3JzLnJpZ2h0LmlzRG93biBvciBAZ2FtZS5pbnB1dC5rZXlib2FyZC5pc0Rvd24oQGtleWJvYXJkX21vZGUucmlnaHQpXG4gICAgICAgICAgICBAcGxheWVyLmJvZHkudmVsb2NpdHkueCA9IEBwbGF5ZXIuc3BlZWRcblxuICAgICAgICAjIFNldCB1cCBvciBkb3duIHZlbG9jaXR5XG4gICAgICAgIGlmIEBjdXJzb3JzLnVwLmlzRG93biBvciBAZ2FtZS5pbnB1dC5rZXlib2FyZC5pc0Rvd24oQGtleWJvYXJkX21vZGUudXApXG4gICAgICAgICAgICBAcGxheWVyLmJvZHkudmVsb2NpdHkueSA9IC0xICogQHBsYXllci5zcGVlZFxuICAgICAgICBlbHNlIGlmIEBjdXJzb3JzLmRvd24uaXNEb3duIG9yIEBnYW1lLmlucHV0LmtleWJvYXJkLmlzRG93bihAa2V5Ym9hcmRfbW9kZS5kb3duKVxuICAgICAgICAgICAgQHBsYXllci5ib2R5LnZlbG9jaXR5LnkgPSBAcGxheWVyLnNwZWVkXG5cbiAgICAgICAgaWYgQGdhbWUuaW5wdXQua2V5Ym9hcmQuZG93bkR1cmF0aW9uKFBoYXNlci5LZXlib2FyZC5TUEFDRUJBUiwgMTApXG4gICAgICAgICAgICBAcGxheWVyLm5leHRUb29sKClcblxuICAgICAgICAjICMgVE9ETzogd2UnbGwgd2FudCB0byBzd2l0Y2ggdGhpcyBzbyB3ZSd2ZSBnb3Qgb3VyIGNoZWNrLWFtbW9cbiAgICAgICAgIyAjIHNjcmVlbiwgcmF0aGVyIHRoYW4gZXhwbGljaXRseSBwcmVzc2luZyB0aGUgUiBrZXkgdG8gcmVsb2FkXG4gICAgICAgICMgaWYgQGdhbWUuaW5wdXQua2V5Ym9hcmQuanVzdFByZXNzZWQoUGhhc2VyLktleWJvYXJkLlIpXG4gICAgICAgICMgICAgIEBwbGF5ZXIucmVsb2FkR3VuKClcbiIsIiMgVGhlIGJ1aWxkIHRvb2wgYWxsb3dzIHRoZSBwbGF5ZXIgdG8gcGxhY2UgdGlsZXNcbmNsYXNzIGV4cG9ydHMuVG9vbEJ1aWxkXG5cbiAgICAjIHRvb2wgbmFtZSBzaG91bGQgYmUgZGlzcGxheWVkIGluIHRoZSBzdGF0dXMgYmFyXG4gICAgbmFtZTogXCJCdWlsZFwiXG5cbiAgICAjIHRoZSB0aWxlIGlkIHRoYXQgaXMgY3VycmVudGx5IHBpY2tlZFxuICAgIGN1cnJlbnRUaWxlSWQ6IDBcblxuICAgICMgdGhlIHRpbGVtYXAgd2UncmUgZ29pbmcgdG8gYmUgY2hhbmdpbmdcbiAgICB0aWxlbWFwOiBudWxsXG5cbiAgICBjb25zdHJ1Y3RvcjogKEBnYW1lLCBAcGxheWVyKS0+XG5cbiAgICAgICAgIyBDcmVhdGUgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBvdXIgZ3VuXG4gICAgICAgIEBndW4gPSBAZ2FtZS5hZGQuc3ByaXRlIDUwLCBAZ2FtZS5oZWlnaHQvMiwgJ3N0YXIyJ1xuXG4gICAgICAgICMgU2V0IHRoZSBwaXZvdCBwb2ludCB0byB0aGUgY2VudGVyIG9mIHRoZSBndW5cbiAgICAgICAgQGd1bi5hbmNob3Iuc2V0VG8gMC41LCAwLjVcblxuICAgICAgICBAZ3VuLnZpc2libGUgPSBmYWxzZVxuXG4gICAgICAgICMgY3JlYXRlIGEgc2VsZWN0aW9uIGN1cnNvclxuICAgICAgICBAc2VsZWN0aW9uID0gQGdhbWUuYWRkLnNwcml0ZSA1MCwgQGdhbWUuaGVpZ2h0LzIsICd0aWxlU2VsZWN0J1xuICAgICAgICBAc2VsZWN0aW9uLmFuY2hvci5zZXRUbyAwLjUsIDAuNVxuXG4gICAgICAgIEBjdXJyZW50VGlsZSA9IDBcbiAgICAgICAgQG1hcCA9IEBnYW1lLmN1cnJlbnRMZXZlbC50aWxlbWFwXG4gICAgICAgIEBjdXJyZW50TGF5ZXIgPSBAZ2FtZS5jdXJyZW50TGV2ZWwuY3VycmVudExheWVyXG5cbiAgICAgICAgcmV0dXJuIHRoaXNcblxuICAgIHNob3dQYWxsZXRlOiAoKS0+XG4gICAgICAgICMgVE9ETzogc2hvdyB0aGUgcGFsbGV0ZSBhdCB0aGUgdG9wIG9mIHRoZSBzY3JlZW5cblxuICAgIGhpZGVQYWxsZXRlOiAoKS0+XG4gICAgICAgICMgVE9ETzogaGlkZSB0aGUgcGFsZXR0ZVxuXG4gICAgcGlja1BhbGxldGVUaWxlOiAoKS0+XG4gICAgICAgICMgVE9ETzogcGljayBhIHRpbGUgZnJvbSB0aGUgcGFsZXR0ZSBhbmQgc2V0IGl0IGFzIGN1cnJlbnRcblxuICAgICMgcGljayBhIHRpbGUgZnJvbSB0aGUgdGlsZW1hcCBhbmQgc2V0IGl0IGFzIHRoZSBjdXJyZW50IHRpbGVcbiAgICBwaWNrVGlsZTogKHgsIHkpLT5cbiAgICAgICAgIyBpZiB0aGUgdGlsZW1hcCBpcyBudWxsLCByZXR1cm5cbiAgICAgICAgaWYgbm90IEB0aWxlbWFwP1xuICAgICAgICAgICAgY29uc29sZS5sb2cgXCJUb29sQnVpbGQucGlja1RpbGU6IEB0aWxlbWFwIGRvZXMgbm90IGV4aXN0XCJcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAjIGdldCBhbmQgYXNzaWduIHRoZSB0aWxlIGlkIGZyb20gdGhlIHRpbGVtYXBcbiAgICAgICAgQGN1cnJlbnRUaWxlSWQgPSAwICMgVE9ETzogZ2V0IHRpbGUgZnJvbSB0aWxlbWFwXG5cbiAgICAjIHJlcGxhY2UgYSB0aWxlIG9uIHRoZSB0aWxlbWFwIHdpdGggdGhlIGN1cnJlbnQgdGlsZVxuICAgIHBhaW50VGlsZTogKHgsIHkpLT5cbiAgICAgICAgIyBpZiB0aGUgdGlsZW1hcCBpcyBudWxsLCByZXR1cm5cbiAgICAgICAgaWYgbm90IEB0aWxlbWFwP1xuICAgICAgICAgICAgY29uc29sZS5sb2cgXCJUb29sQnVpbGQucGFpbnRUaWxlOiBAdGlsZW1hcCBkb2VzIG5vdCBleGlzdFwiXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgIyBUT0RPOiBpZiB0aGUgdGlsZSBhdCB4LCB5IGlzIGFscmVhZHkgdGhlIGN1cnJlbnQgdGlsZSwgcmV0dXJuXG5cbiAgICAgICAgIyBUT0RPOiByZXBsYWNlIHRoZSB0aWxlbWFwIGF0IHgsIHkgd2l0aCB0aGUgY3VycmVudCB0aWxlXG5cbiAgICAjIHRha2VzIGEgc2V0IG9mIHNjcmVlbiBjb29yZGluYXRlcyBhbmQgdHJhbnNsYXRlcyB0aGVtIHRvIHRpbGVtYXAgY29vcmRzXG4gICAgY29vcmRzU2NyZWVuVG9UaWxlbWFwOiAoeCwgeSktPlxuICAgICAgICAjIFRPRE86IHRyYW5zbGF0ZSBhbmQgcmV0dXJuIGNvb3JkaW5hdGVzXG5cbiAgICB1cGRhdGU6ICgpPT5cblxuICAgICAgICAjIE1vdmUgdGhlIGd1biB0byB0aGUgcGxheWVyXG4gICAgICAgIEBndW4ueCA9IEBwbGF5ZXIueFxuICAgICAgICBAZ3VuLnkgPSBAcGxheWVyLnlcblxuICAgICAgICAjIE1vdmUgdGhlIHNlbGVjdGlvbiB0byB0aGUgY3Vyc29yXG4gICAgICAgIEBzZWxlY3Rpb24ueCA9IE1hdGguZmxvb3IoQGdhbWUuaW5wdXQuYWN0aXZlUG9pbnRlci53b3JsZFggLyAzMikgKiAzMiArIDE2XG4gICAgICAgIEBzZWxlY3Rpb24ueSA9IE1hdGguZmxvb3IoQGdhbWUuaW5wdXQuYWN0aXZlUG9pbnRlci53b3JsZFkgLyAzMikgKiAzMiArIDE2XG5cbiAgICAgICAgIyBsLWNsaWNrIHRvIHBhaW50IHRpbGVzXG5cbiAgICAgICAgIyByLWNsaWNrIHRvIHBpY2sgdGlsZXNcblxuICAgICAgICAjIHEgdG8gdG9nZ2xlIHBhbGV0dGVcblxuICAgICAgICAjIGNsaWNrIHRoZSB0aWxlIHBhbGV0dGUgdG8gcGljayBhIHRpbGVcblxuICAgICAgICBtYXJrZXJYID0gQGN1cnJlbnRMYXllci5nZXRUaWxlWChnYW1lLmlucHV0LmFjdGl2ZVBvaW50ZXIud29ybGRYKSAqIDMyXG4gICAgICAgIG1hcmtlclkgPSBAY3VycmVudExheWVyLmdldFRpbGVZKGdhbWUuaW5wdXQuYWN0aXZlUG9pbnRlci53b3JsZFkpICogMzJcblxuICAgICAgICBpZiAoQGdhbWUuaW5wdXQubW91c2VQb2ludGVyLmlzRG93bilcbiAgICAgICAgICAgIEBwbGF5ZXIuYW5pbWF0aW9ucy5wbGF5KCdjYXN0JylcbiAgICAgICAgICAgICMgQG1hcC5wdXRUaWxlKEBjdXJyZW50VGlsZSwgQGN1cnJlbnRMYXllci5nZXRUaWxlWChtYXJrZXJYKSwgQGN1cnJlbnRMYXllci5nZXRUaWxlWShtYXJrZXJZKSwgQGN1cnJlbnRMYXllcilcbiAgICAgICAgICAgIGlmIChnYW1lLmlucHV0LmtleWJvYXJkLmlzRG93bihQaGFzZXIuS2V5Ym9hcmQuU0hJRlQpKVxuICAgICAgICAgICAgICAgIEBjdXJyZW50VGlsZSA9IEBtYXAuZ2V0VGlsZShAY3VycmVudExheWVyLmdldFRpbGVYKG1hcmtlclgpLCBAY3VycmVudExheWVyLmdldFRpbGVZKG1hcmtlclkpKS5pbmRleFxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIGlmIChAbWFwLmdldFRpbGUoQGN1cnJlbnRMYXllci5nZXRUaWxlWChtYXJrZXJYKSwgQGN1cnJlbnRMYXllci5nZXRUaWxlWShtYXJrZXJZKSkuaW5kZXggIT0gQGN1cnJlbnRUaWxlKVxuICAgICAgICAgICAgICAgICAgICBAbWFwLnB1dFRpbGUoQGN1cnJlbnRUaWxlLCBAY3VycmVudExheWVyLmdldFRpbGVYKG1hcmtlclgpLCBAY3VycmVudExheWVyLmdldFRpbGVZKG1hcmtlclkpKVxuICAgICAgICAgICAgICAgICAgICBAZ2FtZS5qdWljZS5wbG9wKGdhbWUuaW5wdXQuYWN0aXZlUG9pbnRlci53b3JsZFgsIGdhbWUuaW5wdXQuYWN0aXZlUG9pbnRlci53b3JsZFkpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIEBwbGF5ZXIuYW5pbWF0aW9ucy5wbGF5KCdpZGxlJylcblxuICAgICAgICBpZiBAZ2FtZS5pbnB1dC5rZXlib2FyZC5kb3duRHVyYXRpb24oUGhhc2VyLktleWJvYXJkLlEsIDEwKVxuICAgICAgICAgICAgQGN1cnJlbnRUaWxlID0gUGhhc2VyLk1hdGguY2xhbXAgQGN1cnJlbnRUaWxlIC0gMSwgMCwgN1xuICAgICAgICAgICAgIyBjb25zb2xlLmxvZyAnY3VycmVudFRpbGUgLS0gdG8gJyArIEBjdXJyZW50VGlsZVxuICAgICAgICBpZiBAZ2FtZS5pbnB1dC5rZXlib2FyZC5kb3duRHVyYXRpb24oUGhhc2VyLktleWJvYXJkLkUsIDEwKVxuICAgICAgICAgICAgQGN1cnJlbnRUaWxlID0gUGhhc2VyLk1hdGguY2xhbXAgQGN1cnJlbnRUaWxlICsgMSwgMCwgN1xuICAgICAgICAgICAgIyBjb25zb2xlLmxvZyAnY3VycmVudFRpbGUgKysgdG8gJyArIEBjdXJyZW50VGlsZVxuXG4gICAgZ2V0U3RhdHVzVGV4dDogKCktPlxuICAgICAgICBzdGF0dXMgPSAnJ1xuICAgICAgICBzdGF0dXMgKz0gJ3RpbGVJRDogJyArIEBjdXJyZW50VGlsZSArICdcXG4nXG4gICAgICAgIHJldHVybiBzdGF0dXNcblxuICAgIHNlbGVjdDogKCktPlxuICAgICAgICBAc2VsZWN0aW9uLnJldml2ZSgpXG5cbiAgICB1bnNlbGVjdDogKCktPlxuICAgICAgICBAc2VsZWN0aW9uLmtpbGwoKVxuXG5cblxuIiwiIyBUaGUgYnVpbGQgdG9vbCBhbGxvd3MgdGhlIHBsYXllciB0byBwbGFjZSB0aWxlc1xuY2xhc3MgZXhwb3J0cy5Ub29sTWlzc2lsZVxuXG4gICAgIyB0b29sIG5hbWUgc2hvdWxkIGJlIGRpc3BsYXllZCBpbiB0aGUgc3RhdHVzIGJhclxuICAgIG5hbWU6IFwiTWFnaWMgTWlzc2lsZVwiXG5cbiAgICAjIERlZmluZSBjb25zdGFudHNcbiAgICBTSE9UX0RFTEFZOiAyNTAgIyBtaWxsaXNlY29uZHNcbiAgICBCVUxMRVRfU1BFRUQ6IDQ1MCAjIHBpeGVscy9zZWNvbmRcbiAgICBOVU1CRVJfT0ZfQlVMTEVUUzogMjBcbiAgICBST1RBVElPTl9PRkZTRVQ6IDBcbiAgICBCVUxMRVRfRU5FUkdZX0NPU1Q6IDUwXG5cbiAgICBjb25zdHJ1Y3RvcjogKEBnYW1lLCBAcGxheWVyKS0+XG5cbiAgICAgICAgQFJPVEFUSU9OX09GRlNFVCA9IFBoYXNlci5NYXRoLmRlZ1RvUmFkIDkwXG5cbiAgICAgICAgIyBDcmVhdGUgYW4gb2JqZWN0IHJlcHJlc2VudGluZyBvdXIgZ3VuXG4gICAgICAgIEBndW4gPSBAZ2FtZS5hZGQuc3ByaXRlIDUwLCBAZ2FtZS5oZWlnaHQvMiwgJ21pc3NpbGUnXG5cbiAgICAgICAgIyBNYWtlIHRoZSBndW4gaW52aXNpYmxlXG4gICAgICAgIEBndW4udmlzaWJsZSA9IGZhbHNlO1xuXG4gICAgICAgICMgU2V0IHRoZSBwaXZvdCBwb2ludCB0byB0aGUgY2VudGVyIG9mIHRoZSBndW5cbiAgICAgICAgQGd1bi5hbmNob3Iuc2V0VG8gMC41LCAwLjVcblxuICAgICAgICAjIGNyZWF0ZSBzb21lIGJ1bGxldHNcbiAgICAgICAgQGNyZWF0ZUJ1bGxldHMoKVxuXG4gICAgICAgIHJldHVybiB0aGlzXG5cbiAgICB1cGRhdGU6ICgpPT5cblxuICAgICAgICAjIE1vdmUgdGhlIGd1biB0byB0aGUgcGxheWVyXG4gICAgICAgIEBndW4ueCA9IEBwbGF5ZXIueFxuICAgICAgICBAZ3VuLnkgPSBAcGxheWVyLnlcbiAgICAgICAgIyBAZ3VuLnJvdGF0aW9uID0gQHBsYXllci5yb3RhdGlvblxuICAgICAgICAjIFJvdGF0ZSB0aGUgZ3VuIHRvIGZhY2UgdGhlIG1vdXNlXG4gICAgICAgIEBndW4ucm90YXRpb24gPSBAZ2FtZS5waHlzaWNzLmFyY2FkZS5hbmdsZVRvUG9pbnRlciBAZ3VuXG5cbiAgICAgICAgIyBzaG90IHRoZSB0aGluZ3NcbiAgICAgICAgaWYgQGZpcmVJbnB1dElzQWN0aXZlKClcbiAgICAgICAgICAgIEBwbGF5ZXIuYW5pbWF0aW9ucy5wbGF5KCdjYXN0JylcbiAgICAgICAgICAgIEBzaG9vdEJ1bGxldCgpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIEBwbGF5ZXIuYW5pbWF0aW9ucy5wbGF5KCdpZGxlJylcblxuICAgICAgICAjIGwtY2xpY2sgdG8gZmlyZVxuXG4gICAgICAgICMgci1jbGljayB0b1xuICAgICAgICAjICAgcGljayB0YXJnZXRzP1xuICAgICAgICAjICAgZ3VpZGUgbWlzc2lsZXM/XG4gICAgICAgICMgICBkZWZlbmQ/XG5cblxuICAgICMgVGhpcyBmdW5jdGlvbiBzaG91bGQgcmV0dXJuIHRydWUgd2hlbiB0aGUgcGxheWVyIGFjdGl2YXRlcyB0aGUgXCJmaXJlXCIgY29udHJvbFxuICAgICMgSW4gdGhpcyBjYXNlLCBlaXRoZXIgaG9sZGluZyB0aGUgc3BhY2UgYmFyXG4gICAgZmlyZUlucHV0SXNBY3RpdmU6ICgpLT5cbiAgICAgICAgaXNBY3RpdmUgPSBmYWxzZTtcblxuICAgICAgICAjIGZpcmVLZXkgPSBAZ2FtZS5pbnB1dC5rZXlib2FyZC5pc0Rvd24gUGhhc2VyLktleWJvYXJkLlNQQUNFQkFSXG4gICAgICAgIGZpcmVCdXR0b24gPSBAZ2FtZS5pbnB1dC5tb3VzZS5idXR0b24gaXMgUGhhc2VyLk1vdXNlLkxFRlRfQlVUVE9OXG5cbiAgICAgICAgIyBpc0FjdGl2ZSA9IGZpcmVLZXkgb3IgZmlyZUJ1dHRvblxuXG4gICAgICAgIHJldHVybiBmaXJlQnV0dG9uXG5cblxuICAgIGNyZWF0ZUJ1bGxldHM6ICgpLT5cblxuICAgICAgICAjIENyZWF0ZSBhbiBvYmplY3QgcG9vbCBvZiBidWxsZXRzXG4gICAgICAgIEBidWxsZXRQb29sID0gQGdhbWUuYWRkLmdyb3VwKClcbiAgICAgICAgZm9yIGkgaW4gWzAuLkBOVU1CRVJfT0ZfQlVMTEVUU11cbiAgICAgICAgICAgICMgQ3JlYXRlIGVhY2ggYnVsbGV0IGFuZCBhZGQgaXQgdG8gdGhlIGdyb3VwLlxuICAgICAgICAgICAgYnVsbGV0ID0gQGdhbWUuYWRkLnNwcml0ZSAwLCAwLCAnbWlzc2lsZSdcbiAgICAgICAgICAgIEBidWxsZXRQb29sLmFkZCBidWxsZXRcblxuICAgICAgICAgICAgIyBTZXQgaXRzIHBpdm90IHBvaW50IHRvIHRoZSBjZW50ZXIgb2YgdGhlIGJ1bGxldFxuICAgICAgICAgICAgIyBidWxsZXQuYW5jaG9yLnNldFRvKDAuNSwgLTAuMjUpO1xuICAgICAgICAgICAgYnVsbGV0LmFuY2hvci5zZXRUbyAwLjUsIDAuNVxuXG4gICAgICAgICAgICAjIEVuYWJsZSBwaHlzaWNzIG9uIHRoZSBidWxsZXRcbiAgICAgICAgICAgIEBnYW1lLnBoeXNpY3MuZW5hYmxlIGJ1bGxldCwgUGhhc2VyLlBoeXNpY3MuQVJDQURFXG5cbiAgICAgICAgICAgICMgR2l2ZSB0aGUgYnVsbGV0IGEgcG93ZXIgdmFsdWUgd2hpY2ggaXQgdXNlcyB0byBkZWFsIGRhbWFnZVxuICAgICAgICAgICAgYnVsbGV0LnBvd2VyID0gMVxuXG4gICAgICAgICAgICAjIFNldCBpdHMgaW5pdGlhbCBzdGF0ZSB0byBcImRlYWRcIi5cbiAgICAgICAgICAgIGJ1bGxldC5raWxsKCk7XG5cblxuICAgIHNob290QnVsbGV0OiAoKS0+XG4gICAgICAgICMgRW5mb3JjZSBhIHNob3J0IGRlbGF5IGJldHdlZW4gc2hvdHMgYnkgcmVjb3JkaW5nXG4gICAgICAgICMgdGhlIHRpbWUgdGhhdCBlYWNoIGJ1bGxldCBpcyBzaG90IGFuZCB0ZXN0aW5nIGlmXG4gICAgICAgICMgdGhlIGFtb3VudCBvZiB0aW1lIHNpbmNlIHRoZSBsYXN0IHNob3QgaXMgbW9yZSB0aGFuXG4gICAgICAgICMgdGhlIHJlcXVpcmVkIGRlbGF5LlxuICAgICAgICBpZiBAbGFzdEJ1bGxldFNob3RBdCBpcyB1bmRlZmluZWRcbiAgICAgICAgICAgIEBsYXN0QnVsbGV0U2hvdEF0ID0gMFxuICAgICAgICBpZiBAZ2FtZS50aW1lLm5vdyAtIEBsYXN0QnVsbGV0U2hvdEF0IDwgQFNIT1RfREVMQVlcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICBAbGFzdEJ1bGxldFNob3RBdCA9IEBnYW1lLnRpbWUubm93XG5cbiAgICAgICAgIyBHZXQgYSBkZWFkIGJ1bGxldCBmcm9tIHRoZSBwb29sXG4gICAgICAgIGJ1bGxldCA9IEBidWxsZXRQb29sLmdldEZpcnN0RGVhZCgpXG5cbiAgICAgICAgIyBJZiB0aGVyZSBhcmVuJ3QgYW55IGJ1bGxldHMgYXZhaWxhYmxlIHRoZW4gZG9uJ3Qgc2hvb3RcbiAgICAgICAgaWYgYnVsbGV0IGlzIG51bGwgb3IgYnVsbGV0IGlzIHVuZGVmaW5lZFxuICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgIyBSZXZpdmUgdGhlIGJ1bGxldFxuICAgICAgICAjIFRoaXMgbWFrZXMgdGhlIGJ1bGxldCBcImFsaXZlXCJcbiAgICAgICAgYnVsbGV0LnJldml2ZSgpXG5cbiAgICAgICAgIyBCdWxsZXRzIHNob3VsZCBraWxsIHRoZW1zZWx2ZXMgd2hlbiB0aGV5IGxlYXZlIHRoZSB3b3JsZC5cbiAgICAgICAgIyBQaGFzZXIgdGFrZXMgY2FyZSBvZiB0aGlzIGZvciBtZSBieSBzZXR0aW5nIHRoaXMgZmxhZ1xuICAgICAgICAjIGJ1dCB5b3UgY2FuIGRvIGl0IHlvdXJzZWxmIGJ5IGtpbGxpbmcgdGhlIGJ1bGxldCBpZlxuICAgICAgICAjIGl0cyB4LHkgY29vcmRpbmF0ZXMgYXJlIG91dHNpZGUgb2YgdGhlIHdvcmxkLlxuICAgICAgICBidWxsZXQuY2hlY2tXb3JsZEJvdW5kcyA9IHRydWVcbiAgICAgICAgYnVsbGV0Lm91dE9mQm91bmRzS2lsbCA9IHRydWVcblxuICAgICAgICAjIFNldCB0aGUgYnVsbGV0IHBvc2l0aW9uIHRvIHRoZSBndW4gcG9zaXRpb24uXG4gICAgICAgIGJ1bGxldC5yZXNldCBAZ3VuLngsIEBndW4ueVxuICAgICAgICBidWxsZXQucm90YXRpb24gPSBAZ3VuLnJvdGF0aW9uIC0gQFJPVEFUSU9OX09GRlNFVFxuICAgICAgICAjIGNvbnNvbGUubG9nKGJ1bGxldC5yb3RhdGlvbik7XG5cbiAgICAgICAgIyBTaG9vdCBpdFxuICAgICAgICBidWxsZXQuYm9keS52ZWxvY2l0eS54ID0gTWF0aC5jb3MoYnVsbGV0LnJvdGF0aW9uICsgQFJPVEFUSU9OX09GRlNFVCkgKiBAQlVMTEVUX1NQRUVEXG4gICAgICAgIGJ1bGxldC5ib2R5LnZlbG9jaXR5LnkgPSBNYXRoLnNpbihidWxsZXQucm90YXRpb24gKyBAUk9UQVRJT05fT0ZGU0VUKSAqIEBCVUxMRVRfU1BFRURcblxuICAgICAgICAjIERvIHNvbWUganVpY2VcbiAgICAgICAgQGdhbWUuanVpY2UucGV3KClcblxuICAgIGdldFN0YXR1c1RleHQ6ICgpLT5cbiAgICAgICAgcmV0dXJuICcnXG5cbiAgICBzZWxlY3Q6ICgpLT5cblxuICAgIHVuc2VsZWN0OiAoKS0+XG4iLCIjIFRoZSBUZWxlcG9ydCB0b29sIGFsbG93cyB0aGUgcGxheWVyIHRvIHRlbGVwb3J0XG5jbGFzcyBleHBvcnRzLlRvb2xUZWxlcG9ydFxuXG4gICAgIyB0b29sIG5hbWUgc2hvdWxkIGJlIGRpc3BsYXllZCBpbiB0aGUgc3RhdHVzIGJhclxuICAgIG5hbWU6IFwiVGVsZXBvcnRcIlxuXG4gICAgY29vbGRvd246IDEwMCAjbXNcblxuICAgIGNvbnN0cnVjdG9yOiAoQGdhbWUsIEBwbGF5ZXIpLT5cblxuICAgICAgICBAdGVsZXBvcnRpbmcgPSBmYWxzZVxuXG4gICAgICAgIHJldHVybiB0aGlzXG5cbiAgICB1cGRhdGU6ICgpPT5cblxuICAgICAgICAjIGwtY2xpY2sgdG8gdGVsZXBvcnRcblxuICAgICAgICAjIHItY2xpY2sgdG8gcGljayB0aWxlc1xuXG4gICAgICAgICMgcSB0byB0b2dnbGUgcGFsZXR0ZVxuXG4gICAgICAgICMgY2xpY2sgdGhlIHRpbGUgcGFsZXR0ZSB0byBwaWNrIGEgdGlsZVxuXG4gICAgICAgIGlmIG5vdCBAdGVsZXBvcnRpbmdcbiAgICAgICAgICAgIGlmIEBnYW1lLmlucHV0Lm1vdXNlUG9pbnRlci5qdXN0UmVsZWFzZWQoQGNvb2xkb3duKVxuICAgICAgICAgICAgICAgIEBwbGF5ZXIuYW5pbWF0aW9ucy5wbGF5KCdjYXN0JylcbiAgICAgICAgICAgICAgICBAcGxheWVyLnggPSBnYW1lLmlucHV0LmFjdGl2ZVBvaW50ZXIud29ybGRYXG4gICAgICAgICAgICAgICAgQHBsYXllci55ID0gZ2FtZS5pbnB1dC5hY3RpdmVQb2ludGVyLndvcmxkWVxuICAgICAgICAgICAgICAgIEBnYW1lLmp1aWNlLnBsb3AoQHBsYXllci54LCBAcGxheWVyLnkpXG4gICAgICAgICAgICAgICAgQHRlbGVwb3J0aW5nID0gdHJ1ZVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICBpZiBub3QgQGdhbWUuaW5wdXQubW91c2VQb2ludGVyLmp1c3RSZWxlYXNlZChAY29vbGRvd24pXG4gICAgICAgICAgICAgICAgQHBsYXllci5hbmltYXRpb25zLnBsYXkoJ2lkbGUnKVxuICAgICAgICAgICAgICAgIEB0ZWxlcG9ydGluZyA9IGZhbHNlXG5cbiAgICBnZXRTdGF0dXNUZXh0OiAoKS0+XG4gICAgICAgIHJldHVybiAndGVsZXBvcnRpbmc6ICcgKyBAdGVsZXBvcnRpbmdcblxuICAgIHNlbGVjdDogKCktPlxuXG4gICAgdW5zZWxlY3Q6ICgpLT5cblxuXG5cbiJdfQ==
